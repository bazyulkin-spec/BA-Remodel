package com.baremodel.app.data

import android.content.Context

/**
 * Пробный период: 30 дней полного доступа с первого запуска.
 * Дата старта пишется один раз и дальше только читается.
 */
class TrialManager(context: Context) {

    private val prefs = context.getSharedPreferences("ba_trial", Context.MODE_PRIVATE)

    val startedAt: Long
        get() {
            val saved = prefs.getLong(KEY_START, 0L)
            if (saved > 0L) return saved
            val now = System.currentTimeMillis()
            prefs.edit().putLong(KEY_START, now).apply()
            return now
        }

    /** Сколько дней пробного периода осталось (0 — закончился). */
    val daysLeft: Int
        get() {
            val passed = (System.currentTimeMillis() - startedAt) / DAY_MS
            return (TRIAL_DAYS - passed).coerceIn(0L, TRIAL_DAYS.toLong()).toInt()
        }

    val isActive: Boolean get() = daysLeft > 0

    companion object {
        const val TRIAL_DAYS = 30
        private const val DAY_MS = 24L * 60 * 60 * 1000
        private const val KEY_START = "started_at"
    }
}
