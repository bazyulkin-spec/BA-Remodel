package com.baremodel.app.ui.editor

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.runtime.remember
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateIntAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.baremodel.app.R
import com.baremodel.app.ui.theme.Acc
import com.baremodel.app.ui.theme.Acc2
import com.baremodel.app.ui.theme.AccDeep
import com.baremodel.app.ui.theme.AccSoft
import com.baremodel.app.ui.theme.BaIcons
import com.baremodel.app.ui.theme.Bg
import com.baremodel.app.ui.theme.Dim
import com.baremodel.app.ui.theme.Line2
import com.baremodel.app.ui.theme.LineC
import com.baremodel.app.ui.theme.Panel
import com.baremodel.app.ui.theme.Panel2
import com.baremodel.app.ui.theme.Panel3
import com.baremodel.app.ui.theme.Sub
import com.baremodel.app.ui.theme.Txt
import com.baremodel.app.ui.theme.Warn
import java.util.Locale

@Composable
fun MainScreen(vm: EditorViewModel = viewModel()) {
    var tab by rememberSaveable { mutableStateOf(0) }
    LaunchedEffect(Unit) { vm.refreshProjects() }

    Column(
        Modifier
            .fillMaxSize()
            .background(Bg)
            .systemBarsPadding(),
    ) {
        TopBar(vm, tab)
        Box(Modifier.weight(1f)) {
            Crossfade(targetState = tab, label = "tab") { t ->
                when (t) {
                    0 -> EditorTab(vm)
                    1 -> View3DScreen(vm)
                    2 -> PhotoFitScreen(vm)
                    3 -> ReportTab(vm)
                    else -> ProScreen()
                }
            }
        }
        BottomNav(tab) { tab = it }
    }
}

@Composable
private fun TopBar(vm: EditorViewModel, tab: Int) {
    Row(
        Modifier
            .fillMaxWidth()
            .background(Brush.verticalGradient(listOf(Panel3.copy(alpha = 0.9f), Panel)))
            .padding(horizontal = 12.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(37.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Brush.linearGradient(listOf(Acc2, AccDeep))),
            contentAlignment = Alignment.Center,
        ) {
            Text("BA", color = Color.White, fontSize = 12.5.sp, fontWeight = FontWeight.ExtraBold)
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    stringResource(R.string.app_name),
                    color = Txt,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false),
                )
                Spacer(Modifier.width(6.dp))
                Text(
                    "BETA",
                    color = Acc,
                    fontSize = 8.5.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    softWrap = false,
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(AccSoft)
                        .padding(horizontal = 5.dp, vertical = 2.dp),
                )
            }
            Text(stringResource(R.string.tagline), color = Dim, fontSize = 10.5.sp, maxLines = 1)
        }
        if (tab == 0) {
            IconToggle(BaIcons.Ruler, vm.showDims) { vm.toggleDims() }
            Spacer(Modifier.width(8.dp))
            IconToggle(BaIcons.Scissors, vm.showCuts) { vm.toggleCuts() }
            Spacer(Modifier.width(8.dp))
            IconToggle(BaIcons.Furn, vm.showFurniture) { vm.toggleFurniture() }
        }
    }
}

@Composable
private fun IconToggle(icon: ImageVector, on: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .size(42.dp)
            .clip(RoundedCornerShape(13.dp))
            .background(if (on) AccSoft else Panel2)
            .border(1.dp, if (on) Acc.copy(alpha = 0.45f) else LineC, RoundedCornerShape(13.dp))
            .clickable { onClick() },
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, null, Modifier.size(20.dp), tint = if (on) Acc else Sub)
    }
}

@Composable
private fun EditorTab(vm: EditorViewModel) {
    Column(Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxWidth().weight(1f)) {
            EditorCanvas(vm, Modifier.fillMaxSize())

            Row(
                Modifier
                    .align(Alignment.TopStart)
                    .padding(13.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Panel2.copy(alpha = 0.88f))
                    .border(1.dp, LineC, RoundedCornerShape(14.dp))
                    .padding(3.dp),
                horizontalArrangement = Arrangement.spacedBy(2.dp),
            ) {
                SegItem(BaIcons.Layers, stringResource(R.string.mode_pattern), !vm.roomMode) { vm.switchRoomMode(false) }
                SegItem(BaIcons.Room, stringResource(R.string.mode_room), vm.roomMode) { vm.switchRoomMode(true) }
            }

            Row(
                Modifier
                    .align(Alignment.TopEnd)
                    .padding(13.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                RoundBtn(BaIcons.Undo, vm.canUndo) { vm.undo() }
                RoundBtn(BaIcons.Redo, vm.canRedo) { vm.redo() }
            }

            Box(
                Modifier
                    .align(Alignment.BottomEnd)
                    .padding(15.dp)
                    .size(52.dp)
                    .shadow(12.dp, RoundedCornerShape(18.dp), spotColor = AccDeep, ambientColor = AccDeep)
                    .clip(RoundedCornerShape(18.dp))
                    .background(Brush.linearGradient(listOf(Acc, AccDeep)))
                    .clickable { vm.fit() },
                contentAlignment = Alignment.Center,
            ) {
                Icon(BaIcons.Fit, null, Modifier.size(21.dp), tint = Color.White)
            }

            val sel = vm.selection
            Fade(
                visible = sel != null,
                modifier = Modifier.align(Alignment.TopCenter).padding(top = 13.dp),
            ) {
                Row(
                    Modifier
                        .clip(RoundedCornerShape(14.dp))
                        .background(Panel2.copy(alpha = 0.92f))
                        .border(1.dp, LineC, RoundedCornerShape(14.dp))
                        .padding(5.dp),
                    horizontalArrangement = Arrangement.spacedBy(5.dp),
                ) {
                    when (sel) {
                        is Selection.Furn -> {
                            Chip("90°") { vm.rotateSelectedFurn() }
                            IconChip(BaIcons.Close, stringResource(R.string.del_furn), warn = true) {
                                vm.deleteSelectedFurniture()
                            }
                        }
                        is Selection.Vertex -> IconChip(
                            BaIcons.Close, stringResource(R.string.del_point), warn = true,
                        ) { vm.deleteSelectedVertex() }
                        is Selection.Cut -> IconChip(
                            BaIcons.Close, stringResource(R.string.del_cutout), warn = true,
                        ) { vm.deleteSelectedCutout() }
                        null -> Unit
                    }
                }
            }

            Fade(
                visible = vm.layout.overLimit,
                modifier = Modifier.align(Alignment.TopCenter).padding(top = 60.dp, start = 16.dp, end = 16.dp),
            ) {
                Text(
                    stringResource(R.string.too_many),
                    color = Warn,
                    fontSize = 11.5.sp,
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(Panel2.copy(alpha = 0.95f))
                        .border(1.dp, Warn.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                        .padding(horizontal = 11.dp, vertical = 8.dp),
                )
            }

            Fade(
                visible = vm.hintVisible && !vm.layout.overLimit,
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 14.dp, start = 16.dp, end = 80.dp),
            ) {
                Text(
                    stringResource(if (vm.roomMode) R.string.hint_room else R.string.hint_pattern),
                    color = Sub,
                    fontSize = 11.sp,
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(Panel2.copy(alpha = 0.88f))
                        .border(1.dp, LineC, RoundedCornerShape(20.dp))
                        .padding(horizontal = 13.dp, vertical = 8.dp),
                )
            }
        }

        // 0 — скрыта · 1 — половина (видно план и настройки) · 2 — полностью
        var sheetState by rememberSaveable { mutableStateOf(1) }
        val panelMax by animateDpAsState(if (sheetState >= 2) 330.dp else 172.dp, label = "sheetH")
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp))
                .background(Panel)
                .border(
                    1.dp,
                    Brush.verticalGradient(listOf(Line2.copy(alpha = 0.8f), Color.Transparent)),
                    RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp),
                ),
        ) {
            Box(
                Modifier
                    .fillMaxWidth()
                    .clickable { sheetState = if (sheetState == 0) 1 else 0 }
                    .pointerInput(Unit) {
                        var acc = 0f
                        detectVerticalDragGestures(
                            onDragStart = { acc = 0f },
                            onDragEnd = {
                                if (acc < -30f) sheetState = (sheetState + 1).coerceAtMost(2)
                                if (acc > 30f) sheetState = (sheetState - 1).coerceAtLeast(0)
                            },
                        ) { change, dy ->
                            acc += dy
                            change.consume()
                        }
                    }
                    .padding(top = 9.dp, bottom = 5.dp),
                contentAlignment = Alignment.Center,
            ) {
                Box(
                    Modifier
                        .size(width = if (sheetState == 2) 58.dp else 42.dp, height = 4.dp)
                        .clip(RoundedCornerShape(99.dp))
                        .background(if (sheetState == 0) Acc.copy(alpha = 0.7f) else Panel3),
                )
            }
            Fade(visible = sheetState > 0) {
                Column(Modifier.fillMaxWidth()) {
                    StatsRow(vm)
                    Box(Modifier.heightIn(max = panelMax)) {
                        PanelHost(vm)
                    }
                }
            }
        }
    }
}

/**
 * Обёртка над AnimatedVisibility: вызывается вне ColumnScope/RowScope,
 * поэтому выбирается обычная перегрузка, а не scope-расширение.
 */
@Composable
private fun Fade(
    visible: Boolean,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit,
) {
    AnimatedVisibility(
        visible = visible,
        modifier = modifier,
        enter = fadeIn(),
        exit = fadeOut(),
    ) {
        content()
    }
}

@Composable
private fun RoundBtn(icon: ImageVector, enabled: Boolean, onClick: () -> Unit) {
    val alpha by animateFloatAsState(if (enabled) 1f else 0.32f, label = "btn")
    val press = remember { MutableInteractionSource() }
    val pressed by press.collectIsPressedAsState()
    val k by animateFloatAsState(if (pressed && enabled) 0.9f else 1f, label = "btnK")
    Box(
        Modifier
            .graphicsLayer { scaleX = k; scaleY = k }
            .size(44.dp)
            .shadow(6.dp, RoundedCornerShape(14.dp))
            .clip(RoundedCornerShape(13.dp))
            .background(Panel2.copy(alpha = 0.88f))
            .border(1.dp, LineC, RoundedCornerShape(13.dp))
            .clickable(enabled = enabled, interactionSource = press, indication = null) { onClick() },
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, null, Modifier.size(19.dp), tint = Acc2.copy(alpha = alpha))
    }
}

@Composable
private fun SegItem(icon: ImageVector, text: String, on: Boolean, onClick: () -> Unit) {
    Row(
        Modifier
            .clip(RoundedCornerShape(11.dp))
            .background(if (on) Brush.linearGradient(listOf(Acc, AccDeep)) else Brush.linearGradient(listOf(Color.Transparent, Color.Transparent)))
            .clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, Modifier.size(16.dp), tint = if (on) Color.White else Sub)
        Spacer(Modifier.width(6.dp))
        Text(text, color = if (on) Color.White else Sub, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun StatsRow(vm: EditorViewModel) {
    val l = vm.layout
    val full by animateIntAsState(l.fullCount, label = "full")
    val cut by animateIntAsState(l.cutCount, label = "cut")
    val buy by animateIntAsState(vm.buyCount, label = "buy")
    val tileAreaM2 = vm.tile.widthMm * vm.tile.heightMm / 1_000_000.0
    val unitPc = if (vm.prices.tilePc > 0) vm.prices.tilePc else vm.prices.tileM2 * tileAreaM2
    val roomName = vm.rooms.getOrNull(vm.activeRoom)?.name?.takeIf { it.isNotBlank() }
        ?: stringResource(R.string.room_n, vm.activeRoom + 1)
    Row(
        Modifier
            .fillMaxWidth()
            .padding(start = 15.dp, end = 15.dp, top = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Bottom,
    ) {
        Text(roomName, color = Acc2, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
        if (vm.rooms.size > 1) {
            Text(stringResource(R.string.stats_hint), color = Dim, fontSize = 9.5.sp)
        }
    }
    Row(
        Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(start = 14.dp, end = 14.dp, top = 6.dp, bottom = 10.dp),
        horizontalArrangement = Arrangement.spacedBy(9.dp),
    ) {
        Stat(
            stringResource(R.string.area),
            String.format(Locale.getDefault(), "%.2f", l.areaM2),
            stringResource(R.string.unit_m2),
        )
        Stat(stringResource(R.string.full_tiles), full.toString())
        Stat(stringResource(R.string.cut_tiles), cut.toString(), valueColor = Warn)
        Stat(
            stringResource(R.string.buy),
            buy.toString(),
            stringResource(R.string.pcs),
            accent = true,
            extra = if (unitPc > 0) {
                money(vm.buyCount * unitPc, vm.prices.currency) + " · +${vm.reservePct}%"
            } else {
                "+${vm.reservePct}%"
            },
        )
    }
}

@Composable
private fun Stat(
    label: String,
    value: String,
    unit: String? = null,
    valueColor: Color = Txt,
    accent: Boolean = false,
    extra: String? = null,
) {
    Column(
        Modifier
            .widthIn(min = 88.dp)
            .clip(RoundedCornerShape(13.dp))
            .then(
                if (accent) {
                    Modifier.background(
                        Brush.linearGradient(listOf(Acc.copy(alpha = 0.30f), Acc.copy(alpha = 0.10f))),
                    )
                } else {
                    Modifier.background(Panel2)
                },
            )
            .border(1.dp, if (accent) Acc.copy(alpha = 0.4f) else LineC, RoundedCornerShape(13.dp))
            .padding(horizontal = 12.dp, vertical = 10.dp),
    ) {
        Text(label.uppercase(Locale.getDefault()), color = Dim, fontSize = 9.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(4.dp))
        Row(verticalAlignment = Alignment.Bottom) {
            Text(
                value,
                color = if (accent) Acc2 else valueColor,
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold,
            )
            if (unit != null) {
                Spacer(Modifier.width(3.dp))
                Text(unit, color = Dim, fontSize = 10.5.sp, modifier = Modifier.padding(bottom = 2.dp))
            }
            if (extra != null) {
                Spacer(Modifier.width(5.dp))
                Text(extra, color = Acc, fontSize = 10.sp, modifier = Modifier.padding(bottom = 2.dp))
            }
        }
    }
}

@Composable
private fun BottomNav(tab: Int, onTab: (Int) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .background(Panel)
            .padding(horizontal = 8.dp, vertical = 7.dp),
    ) {
        NavItem(BaIcons.Tile, stringResource(R.string.tab_editor), tab == 0, Modifier.weight(1f)) { onTab(0) }
        NavItem(BaIcons.Cube, stringResource(R.string.tab_3d), tab == 1, Modifier.weight(1f)) { onTab(1) }
        NavItem(BaIcons.Camera, stringResource(R.string.tab_fit), tab == 2, Modifier.weight(1f)) { onTab(2) }
        NavItem(BaIcons.Doc, stringResource(R.string.tab_report), tab == 3, Modifier.weight(1f)) { onTab(3) }
        NavItem(BaIcons.Star, stringResource(R.string.tab_pro), tab == 4, Modifier.weight(1f)) { onTab(4) }
    }
}

@Composable
private fun NavItem(
    icon: ImageVector,
    label: String,
    selected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    val pill by animateColorAsState(if (selected) AccSoft else Color.Transparent, label = "navPill")
    val tint by animateColorAsState(if (selected) Acc else Dim, label = "navTint")
    val text by animateColorAsState(if (selected) Txt else Dim, label = "navText")
    val press = remember { MutableInteractionSource() }
    val pressed by press.collectIsPressedAsState()
    val k by animateFloatAsState(if (pressed) 0.92f else 1f, label = "navK")
    val haptic = LocalHapticFeedback.current
    Column(
        modifier
            .graphicsLayer { scaleX = k; scaleY = k }
            .clip(RoundedCornerShape(14.dp))
            .clickable(interactionSource = press, indication = null) {
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onClick()
            }
            .padding(vertical = 5.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            Modifier
                .clip(RoundedCornerShape(99.dp))
                .background(pill)
                .padding(horizontal = 17.dp, vertical = 4.dp),
        ) {
            Icon(icon, null, Modifier.size(20.dp), tint = tint)
        }
        Spacer(Modifier.height(3.dp))
        Text(label, color = text, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
    }
}
