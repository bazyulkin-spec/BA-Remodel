package com.baremodel.app.ui.editor

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.baremodel.app.R
import com.baremodel.app.ui.theme.Acc2
import com.baremodel.app.ui.theme.CanvasBg
import com.baremodel.app.ui.theme.Dim
import com.baremodel.app.ui.theme.LineC
import com.baremodel.app.ui.theme.Panel
import com.baremodel.app.ui.theme.Panel2
import com.baremodel.app.ui.theme.Sub
import com.baremodel.app.ui.theme.Txt
import com.baremodel.app.ui.theme.Warn
import com.baremodel.core.Finish
import com.baremodel.core.Pt
import com.baremodel.core.TileClass
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** Точка в пространстве: x и z — план, y — высота. */
private data class V3(val x: Float, val y: Float, val z: Float)

/** Грань для отрисовки: вершины, цвет и глубина для сортировки. */
private class Face(
    val pts: List<Offset>,
    val color: Color,
    val depth: Float,
    val outline: Color? = null,
    val bmp: android.graphics.Bitmap? = null,
)

private const val MAX_TEXTURED_3D = 420

private const val MAX_TILES_3D = 1400

@Composable
fun View3DScreen(vm: EditorViewModel) {
    var yaw by rememberSaveable { mutableFloatStateOf(0.6f) }
    var pitch by rememberSaveable { mutableFloatStateOf(0.62f) }
    var dist by rememberSaveable { mutableFloatStateOf(1.35f) }

    // раскладка плитки на стенах считается один раз на изменение данных, а не каждый кадр
    val wallLayouts = remember(vm.room, vm.tile, vm.pattern, vm.wallHeightM, vm.finishes, vm.openings) {
        vm.model.walls
            .filter { vm.finishOf(it.id) == Finish.TILE }
            .associate { it.id to vm.surfaceLayout(it.id) }
    }

    Column(Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxWidth().weight(1f)) {
            Canvas(
                Modifier
                    .fillMaxSize()
                    .background(CanvasBg)
                    .pointerInput(Unit) {
                        awaitEachGesture {
                            awaitFirstDown()
                            var pinching = false
                            var d0 = 1f
                            var base = dist
                            while (true) {
                                val ev = awaitPointerEvent()
                                val act = ev.changes.filter { it.pressed }
                                if (act.size >= 2) {
                                    val dd = max(1f, (act[0].position - act[1].position).getDistance())
                                    if (!pinching) { pinching = true; d0 = dd; base = dist }
                                    else dist = (base * d0 / dd).coerceIn(0.55f, 4f)
                                } else if (act.size == 1 && !pinching) {
                                    val c = act[0]
                                    val dx = c.position.x - c.previousPosition.x
                                    val dy = c.position.y - c.previousPosition.y
                                    yaw -= dx * 0.008f
                                    pitch = (pitch + dy * 0.006f).coerceIn(0.12f, 1.45f)
                                }
                                ev.changes.forEach { it.consume() }
                                if (act.isEmpty()) break
                            }
                        }
                    },
            ) {
                val pts = vm.room.points
                if (pts.size < 3) return@Canvas

                val minx = pts.minOf { it.x }.toFloat()
                val maxx = pts.maxOf { it.x }.toFloat()
                val minz = pts.minOf { it.y }.toFloat()
                val maxz = pts.maxOf { it.y }.toFloat()
                val cx = (minx + maxx) / 2f
                val cz = (minz + maxz) / 2f
                val span = max(maxx - minx, maxz - minz).coerceAtLeast(1f)
                val wallH = vm.wallHeightM.toFloat()

                // камера подбирается так, чтобы комната заполняла кадр
                val fitSpan = max(span, wallH * 1.5f)
                val radius = fitSpan * 1.32f * dist
                val cyaw = cos(yaw); val syaw = sin(yaw)
                val cp = cos(pitch); val sp = sin(pitch)
                val focal = min(size.width, size.height) * 0.95f
                val ox = size.width / 2f
                val oy = size.height / 2f + size.height * 0.06f

                // положение камеры в мире — нужно для отсечения ближних стен
                val camX = cx + radius * cp * syaw
                val camY = radius * sp
                val camZ = cz + radius * cp * cyaw

                fun project(p: V3): Pair<Offset, Float> {
                    val dx = p.x - cx
                    val dy = p.y
                    val dz = p.z - cz
                    val rx = dx * cyaw - dz * syaw
                    val rz = dx * syaw + dz * cyaw
                    val ry = dy * cp - rz * sp
                    val rz2 = dy * sp + rz * cp
                    val vz = radius - rz2
                    if (vz < 0.05f) return Offset(Float.NaN, Float.NaN) to -1f
                    return Offset(ox + focal * rx / vz, oy - focal * ry / vz) to vz
                }

                // фон: мягкий градиент вместо плоской заливки
                drawRect(
                    Brush.verticalGradient(
                        0f to Color(0xFF0C1119),
                        0.55f to Color(0xFF070A10),
                        1f to Color(0xFF05070B),
                    ),
                    size = size,
                )

                val faces = ArrayList<Face>(1400)

                fun addFace(
                    v: List<V3>,
                    color: Color,
                    outline: Color? = null,
                    bmp: android.graphics.Bitmap? = null,
                ) {
                    val proj = v.map { project(it) }
                    if (proj.any { it.second < 0f }) return
                    val depth = proj.sumOf { it.second.toDouble() }.toFloat() / proj.size
                    faces.add(Face(proj.map { it.first }, color, depth, outline, bmp))
                }

                fun shade(c: Color, k: Float) = Color(
                    (c.red * k).coerceIn(0f, 1f),
                    (c.green * k).coerceIn(0f, 1f),
                    (c.blue * k).coerceIn(0f, 1f),
                    c.alpha,
                )

                // основание пола (цвет шва)
                addFace(pts.map { V3(it.x.toFloat(), 0f, it.y.toFloat()) }, Color(0xFF465065))

                // плитки пола
                val tiles = vm.layout.tiles
                val decorSet = vm.decorIdx
                val tileBmp = if (tiles.size <= MAX_TEXTURED_3D) vm.tileImage?.asAndroidBitmap() else null
                val decorBmp = if (tiles.size <= MAX_TEXTURED_3D) {
                    (vm.decorImage ?: vm.tileImage)?.asAndroidBitmap()
                } else null
                if (tiles.size <= MAX_TILES_3D) {
                    tiles.forEachIndexed { i, t ->
                        val isDecor = i in decorSet
                        val base = when {
                            isDecor -> Color(0xFFE8DFD2)
                            t.cls == TileClass.CUT -> shade(vm.tileColor, 0.93f)
                            else -> vm.tileColor
                        }
                        val hs = abs(sin(t.rect.x * 127.1 + t.rect.y * 311.7) * 43758.5453) % 1.0
                        val k = 0.95f + (hs.toFloat() - 0.5f) * 0.08f
                        val face = if (isDecor) decorBmp else tileBmp
                        addFace(
                            t.corners.map { V3(it.x.toFloat(), 0.001f, it.y.toFloat()) },
                            shade(base, k),
                            when {
                                t.cls == TileClass.CUT && vm.showCuts -> Warn.copy(alpha = 0.55f)
                                else -> Color(0xFF2A3140) // шов между плитками
                            },
                            face,
                        )
                    }
                }

                // стены: рисуем только дальние, ближние убираем, чтобы видеть комнату внутри
                for (i in pts.indices) {
                    val a = pts[i]
                    val b = pts[(i + 1) % pts.size]
                    val ax = a.x.toFloat(); val az = a.y.toFloat()
                    val bx = b.x.toFloat(); val bz = b.y.toFloat()
                    val len = hypot(bx - ax, bz - az)
                    if (len < 1e-4f) continue
                    // внешняя нормаль
                    var nx = (bz - az) / len
                    var nz = -(bx - ax) / len
                    val mx = (ax + bx) / 2f
                    val mz = (az + bz) / 2f
                    val inside = Pt((mx + nx * 0.05f).toDouble(), (mz + nz * 0.05f).toDouble())
                    if (com.baremodel.core.pointInPolygon(inside, pts)) { nx = -nx; nz = -nz }
                    // стена между камерой и комнатой — пропускаем
                    if (nx * (camX - mx) + nz * (camZ - mz) > 0f) continue
                    val tone = 0.42f + 0.16f * abs(nz)
                    val wallId = "wall-" + (i + 1)
                    val fin = vm.finishOf(wallId)
                    val baseCol = when (fin) {
                        Finish.TILE -> Color(0xFF8E99AB)
                        Finish.WALLPAPER -> Color(0xFFB6A894)
                        Finish.PAINT -> Color(0xFFA8B2C2)
                        Finish.NONE -> Color(0xFF6E7889)
                    }
                    addFace(
                        listOf(
                            V3(ax, 0f, az), V3(bx, 0f, bz),
                            V3(bx, wallH, bz), V3(ax, wallH, az),
                        ),
                        shade(baseCol, tone),
                        LineC,
                    )

                    // плитка на стене
                    val ux = (bx - ax) / len
                    val uz = (bz - az) / len
                    val wl = wallLayouts[wallId]
                    if (wl != null && wl.tiles.size <= 700) {
                        wl.tiles.forEach { t ->
                            val quad = t.corners.map { c ->
                                V3(
                                    ax + ux * c.x.toFloat() + nx * 0.004f,
                                    c.y.toFloat(),
                                    az + uz * c.x.toFloat() + nz * 0.004f,
                                )
                            }
                            val col = if (t.cls == TileClass.CUT) shade(vm.tileColor, 0.9f) else vm.tileColor
                            addFace(quad, shade(col, tone + 0.30f), Color(0xFF2A3140))
                        }
                    }

                    // проёмы: окна и двери
                    vm.openingsOf(wallId).forEach { o ->
                        val ox0 = o.x.toFloat()
                        val ox1 = (o.x + o.w).toFloat()
                        val oy0 = o.y.toFloat()
                        val oy1 = (o.y + o.h).toFloat()
                        addFace(
                            listOf(
                                V3(ax + ux * ox0 + nx * 0.008f, oy0, az + uz * ox0 + nz * 0.008f),
                                V3(ax + ux * ox1 + nx * 0.008f, oy0, az + uz * ox1 + nz * 0.008f),
                                V3(ax + ux * ox1 + nx * 0.008f, oy1, az + uz * ox1 + nz * 0.008f),
                                V3(ax + ux * ox0 + nx * 0.008f, oy1, az + uz * ox0 + nz * 0.008f),
                            ),
                            Color(0xFF0A0E15),
                            Acc2.copy(alpha = 0.45f),
                        )
                    }
                }

                // мебель — коробки по высоте
                if (vm.showFurniture) {
                    vm.furniture.forEach { f ->
                        val x0 = f.x.toFloat(); val z0 = f.y.toFloat()
                        // мягкая тень на полу
                        addFace(
                            listOf(
                                V3(x0 - 0.03f, 0.004f, z0 - 0.03f),
                                V3((f.x + f.w).toFloat() + 0.06f, 0.004f, z0 - 0.03f),
                                V3((f.x + f.w).toFloat() + 0.06f, 0.004f, (f.y + f.h).toFloat() + 0.06f),
                                V3(x0 - 0.03f, 0.004f, (f.y + f.h).toFloat() + 0.06f),
                            ),
                            Color(0x2E000000),
                        )
                        val x1 = (f.x + f.w).toFloat(); val z1 = (f.y + f.h).toFloat()
                        val h = f.heightM.toFloat().coerceIn(0.05f, 3f)
                        val body = Color(0xFF20293A)
                        addFace(listOf(V3(x0, 0f, z0), V3(x1, 0f, z0), V3(x1, h, z0), V3(x0, h, z0)), shade(body, 0.9f), LineC)
                        addFace(listOf(V3(x1, 0f, z0), V3(x1, 0f, z1), V3(x1, h, z1), V3(x1, h, z0)), shade(body, 0.78f), LineC)
                        addFace(listOf(V3(x1, 0f, z1), V3(x0, 0f, z1), V3(x0, h, z1), V3(x1, h, z1)), shade(body, 1.05f), LineC)
                        addFace(listOf(V3(x0, 0f, z1), V3(x0, 0f, z0), V3(x0, h, z0), V3(x0, h, z1)), shade(body, 0.84f), LineC)
                        addFace(listOf(V3(x0, h, z0), V3(x1, h, z0), V3(x1, h, z1), V3(x0, h, z1)), shade(body, 1.35f), Acc2.copy(alpha = 0.6f))
                    }
                }

                // дальние грани рисуются первыми
                faces.sortByDescending { it.depth }
                faces.forEach { face ->
                    if (face.pts.any { it.x.isNaN() }) return@forEach
                    val path = Path().apply {
                        moveTo(face.pts[0].x, face.pts[0].y)
                        for (k in 1 until face.pts.size) lineTo(face.pts[k].x, face.pts[k].y)
                        close()
                    }
                    val bmp = face.bmp
                    if (bmp != null && face.pts.size == 4) {
                        // фото плитки натягивается на грань: 4 вершины сетки
                        drawIntoCanvas { canvas ->
                            val verts = floatArrayOf(
                                face.pts[0].x, face.pts[0].y,
                                face.pts[1].x, face.pts[1].y,
                                face.pts[3].x, face.pts[3].y,
                                face.pts[2].x, face.pts[2].y,
                            )
                            canvas.nativeCanvas.drawBitmapMesh(bmp, 1, 1, verts, 0, null, 0, null)
                        }
                    } else {
                        drawPath(path, face.color)
                    }
                    face.outline?.let {
                        drawPath(path, it, style = androidx.compose.ui.graphics.drawscope.Stroke(1.1f * density))
                    }
                }
            }

            if (vm.layout.tiles.size > MAX_TILES_3D) {
                Text(
                    stringResource(R.string.too_many),
                    color = Warn,
                    fontSize = 11.5.sp,
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(12.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Panel2.copy(alpha = 0.95f))
                        .padding(horizontal = 11.dp, vertical = 8.dp),
                )
            }

            if (Entitlements.watermark) {
                Text(
                    stringResource(R.string.app_name),
                    color = Txt.copy(alpha = 0.22f),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(start = 14.dp, bottom = 14.dp),
                )
            }

            Text(
                stringResource(R.string.view_hint),
                color = Sub,
                fontSize = 11.sp,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 12.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(Panel.copy(alpha = 0.9f))
                    .padding(horizontal = 13.dp, vertical = 8.dp),
            )
        }

        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp))
                .background(Panel)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
        ) {
            Text(stringResource(R.string.wall_height), color = Dim, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(2.4, 2.7, 3.0).forEach { h ->
                    Chip("$h " + stringResource(R.string.unit_m), abs(vm.wallHeightM - h) < 0.01) {
                        vm.setWallHeight(h)
                    }
                }
                Chip(stringResource(R.string.reset_view)) {
                    yaw = 0.6f; pitch = 0.62f; dist = 1.35f
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(13.dp))
                    .background(Panel2)
                    .border(1.dp, LineC, RoundedCornerShape(13.dp))
                    .clickable { }
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text(stringResource(R.string.view_note), color = Sub, fontSize = 11.5.sp)
            }
            Spacer(Modifier.height(8.dp))
            Text(stringResource(R.string.hint_3d), color = Dim, fontSize = 10.5.sp)
            Spacer(Modifier.height(6.dp))
            Text(
                stringResource(R.string.credit),
                color = Dim,
                fontSize = 10.sp,
                modifier = Modifier.fillMaxWidth(),
            )
        }
    }
}
