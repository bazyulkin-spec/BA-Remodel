package com.baremodel.app.data

import com.baremodel.core.AnchorMode
import com.baremodel.core.Cutout
import com.baremodel.core.Finish
import com.baremodel.core.Furniture
import com.baremodel.core.DecorSpec
import com.baremodel.core.PatternSpec
import com.baremodel.core.RoomSpec
import com.baremodel.core.TileSpec
import kotlinx.serialization.Serializable

/** Цены мастера: материалы и работа. Нули означают «не считать». */
@Serializable
data class Prices(
    val tileM2: Double = 0.0,
    val tilePc: Double = 0.0,
    val adhesiveKg: Double = 0.0,
    val roll: Double = 0.0,
    val paintL: Double = 0.0,
    val workTileM2: Double = 0.0,
    val workWallM2: Double = 0.0,
    val workPaintM2: Double = 0.0,
    val currency: String = "₪",
)

/** Метаданные сохранённого проекта для списка. */
data class ProjectMeta(val name: String, val savedAt: Long)

/** Снимок проекта для сохранения на диск (JSON). */
@Serializable
data class ProjectDto(
    val name: String,
    val room: RoomSpec,
    val tile: TileSpec,
    val pattern: PatternSpec,
    val colorArgb: Int,
    val variation: Boolean = true,
    val reservePct: Int = 10,
    val decor: DecorSpec = DecorSpec(),
    val anchor: AnchorMode = AnchorMode.FREE,
    val furniture: List<Furniture> = emptyList(),
    val finishes: Map<String, Finish> = emptyMap(),
    val openings: Map<String, List<Cutout>> = emptyMap(),
    val wallHeightM: Double = 2.7,
    val prices: Prices = Prices(),
    val savedAt: Long = 0L,
)
