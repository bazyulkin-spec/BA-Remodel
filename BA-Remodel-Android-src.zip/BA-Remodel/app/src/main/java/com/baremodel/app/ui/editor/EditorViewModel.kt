package com.baremodel.app.ui.editor

import android.app.Application
import android.content.Context
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.widget.Toast
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.toArgb
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.baremodel.app.R
import android.content.Intent
import androidx.compose.ui.graphics.asAndroidBitmap
import com.baremodel.app.ar.ArActivity
import com.baremodel.app.ar.ArBridge
import com.baremodel.app.ar.renderFloorBitmap
import com.baremodel.app.data.Prices
import com.baremodel.app.data.RoomDto
import java.io.File
import com.baremodel.app.data.ProjectDto
import com.baremodel.app.data.ProjectMeta
import com.baremodel.app.data.ProjectRepository
import com.baremodel.core.Aligner
import com.baremodel.core.AnchorMode
import com.baremodel.core.ArtRect
import com.baremodel.core.CutAnalyzer
import com.baremodel.core.CutReport
import com.baremodel.core.CoverageAnalyzer
import com.baremodel.core.CoverageReport
import com.baremodel.core.Cutout
import com.baremodel.core.Furniture
import com.baremodel.core.DecorMode
import com.baremodel.core.DecorPlanner
import com.baremodel.core.DecorSpec
import com.baremodel.core.Finish
import com.baremodel.core.RoomModel
import com.baremodel.core.SurfaceKind
import com.baremodel.core.LayoutResult
import com.baremodel.core.LayoutSuggester
import com.baremodel.core.MaterialCalc
import com.baremodel.core.areaM2
import com.baremodel.core.PatternSpec
import com.baremodel.core.PatternType
import com.baremodel.core.Pt
import com.baremodel.core.RoomSpec
import com.baremodel.core.TileSpec
import com.baremodel.core.TilingEngine
import com.baremodel.core.pointInPolygon
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** Экранное преобразование: метры → пиксели. */
data class ViewTransform(val scale: Float = 110f, val offset: Offset = Offset(40f, 60f))

sealed interface Selection {
    data class Vertex(val i: Int) : Selection
    data class Cut(val i: Int) : Selection
    data class Furn(val i: Int) : Selection
}

/** Стоимость поверхности: материалы и работа. */
data class SurfaceCost(
    val id: String,
    val finish: Finish,
    val areaM2: Double,
    val materials: Double,
    val work: Double,
)

class EditorViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = ProjectRepository(app)

    // ---------- состояние ----------

    var room by mutableStateOf(
        RoomSpec(listOf(Pt(0.0, 0.0), Pt(4.0, 0.0), Pt(4.0, 3.0), Pt(0.0, 3.0)))
    )
        private set

    var tile by mutableStateOf(TileSpec(600.0, 600.0, 3.0))
        private set

    var pattern by mutableStateOf(PatternSpec())
        private set

    var tileColor by mutableStateOf(Color(0xFFC7CCD6))
        private set

    var variation by mutableStateOf(true)
        private set

    var tileImage by mutableStateOf<ImageBitmap?>(null)
        private set

    var decor by mutableStateOf(DecorSpec())
        private set

    var anchor by mutableStateOf(AnchorMode.FREE)
        private set

    var decorImage by mutableStateOf<ImageBitmap?>(null)
        private set

    var furniture by mutableStateOf<List<Furniture>>(emptyList())
        private set

    var reservePct by mutableStateOf(10)
        private set

    var roomMode by mutableStateOf(false)
        private set

    var showDims by mutableStateOf(true)
        private set

    var showCuts by mutableStateOf(true)
        private set

    var showFurniture by mutableStateOf(true)
        private set

    /** Показ области рисунка на каждой плитке плана. */
    var showArt by mutableStateOf(false)
        private set

    var wallHeightM by mutableStateOf(2.7)
        private set

    // ---------- квартира: несколько комнат ----------

    /** Все комнаты квартиры; запись активной обновляется при переключении и сохранении. */
    var rooms by mutableStateOf(listOf<RoomDto>())
        private set

    var activeRoom by mutableStateOf(0)
        private set

    /** Снимок текущих полей как комната. */
    private fun snapshotRoom(name: String): RoomDto = RoomDto(
        name = name,
        spec = room,
        tile = tile,
        pattern = pattern,
        colorArgb = tileColor.toArgb(),
        variation = variation,
        decor = decor,
        anchor = anchor,
        finishes = finishes,
        openings = openings,
    )

    private fun applyRoom(d: RoomDto) {
        room = d.spec
        tile = d.tile
        pattern = d.pattern
        if (d.colorArgb != -1) tileColor = Color(d.colorArgb)
        variation = d.variation
        decor = d.decor
        anchor = d.anchor
        finishes = d.finishes
        openings = d.openings
        selection = null
        suggestions = null
        reanchor()
    }

    /** Обновить запись активной комнаты в списке. */
    fun syncActiveRoom() {
        val list = rooms.toMutableList()
        if (activeRoom in list.indices) {
            list[activeRoom] = snapshotRoom(list[activeRoom].name)
            rooms = list
        } else if (list.isEmpty()) {
            rooms = listOf(snapshotRoom(""))
            activeRoom = 0
        }
    }

    fun switchRoom(i: Int) {
        if (i == activeRoom || i !in rooms.indices) return
        pushUndo()
        syncActiveRoom()
        activeRoom = i
        applyRoom(rooms[i])
    }

    /** Новая комната справа от габарита квартиры, наследует плитку и узор текущей. */
    fun addRoom() {
        pushUndo()
        syncActiveRoom()
        val all = rooms.flatMap { it.spec.points } + room.points
        val maxX = all.maxOf { it.x }
        val minY = all.minOf { it.y }
        val x0 = round2(maxX + 0.4)
        val y0 = round2(minY)
        val spec = RoomSpec(
            listOf(Pt(x0, y0), Pt(x0 + 3.0, y0), Pt(x0 + 3.0, y0 + 2.4), Pt(x0, y0 + 2.4)),
        )
        val d = snapshotRoom("").copy(
            spec = spec,
            decor = DecorSpec(),
            anchor = AnchorMode.FREE,
            finishes = emptyMap(),
            openings = emptyMap(),
        )
        rooms = rooms + d
        activeRoom = rooms.lastIndex
        applyRoom(d)
        fit()
    }

    fun deleteActiveRoom() {
        if (rooms.size <= 1) return
        pushUndo()
        val list = rooms.toMutableList()
        list.removeAt(activeRoom)
        rooms = list
        activeRoom = activeRoom.coerceAtMost(list.lastIndex)
        applyRoom(list[activeRoom])
        fit()
    }

    /** Сводный итог по всем комнатам: штук к покупке и деньги при заданной цене. */
    fun apartmentPieces(): Pair<Int, Double> {
        var pieces = 0
        var moneySum = 0.0
        rooms.forEachIndexed { i, r ->
            val t = if (i == activeRoom) tile else r.tile
            val lay = if (i == activeRoom) layout else TilingEngine.build(r.spec, r.tile, r.pattern)
            val cnt = ceil(lay.totalCount * (1 + reservePct / 100.0)).toInt()
            pieces += cnt
            val areaM2 = t.widthMm * t.heightMm / 1_000_000.0
            val unit = if (prices.tilePc > 0) prices.tilePc else prices.tileM2 * areaM2
            moneySum += cnt * unit
        }
        return pieces to moneySum
    }

    init {
        // посев: активная комната всегда представлена в списке
        if (rooms.isEmpty()) rooms = listOf(snapshotRoom(""))
    }

    /** Цены мастера: сохраняются вместе с проектом. */
    var prices by mutableStateOf(Prices())
        private set

    /** Фото пола для примерки (живёт в рамках сеанса). */
    var fitPhoto by mutableStateOf<ImageBitmap?>(null)
        private set

    /** Четыре угла пола на фото, в долях кадра: слева-сверху по часовой. */
    var fitQuad by mutableStateOf(
        listOf(Offset(0.16f, 0.34f), Offset(0.84f, 0.34f), Offset(0.97f, 0.93f), Offset(0.03f, 0.93f)),
    )
        private set

    /** Прозрачность наложенной раскладки. */
    var fitAlpha by mutableStateOf(0.8f)
        private set

    /** Логотип мастера для шапки PDF; хранится в filesDir/logo.png. */
    var masterLogo by mutableStateOf<ImageBitmap?>(null)
        private set

    /** Отделка по поверхностям: floor / wall-N / ceiling. */
    var finishes by mutableStateOf(mapOf("floor" to Finish.TILE, "ceiling" to Finish.PAINT))
        private set

    /** Проёмы (окна, двери) в координатах развёртки стены. */
    var openings by mutableStateOf(mapOf<String, List<Cutout>>())
        private set

    var activeSurface by mutableStateOf("floor")
        private set

    /** Плотность экрана: пороги захвата пальцем задаются в dp и умножаются на неё. */
    private var uiScale = 1f

    fun updateUiScale(v: Float) { uiScale = v.coerceIn(0.5f, 5f) }

    var selection by mutableStateOf<Selection?>(null)
        private set

    var view by mutableStateOf(ViewTransform())
        private set

    var hintVisible by mutableStateOf(true)
        private set

    var projectName by mutableStateOf("")

    var projects by mutableStateOf<List<ProjectMeta>>(emptyList())
        private set

    var suggestions by mutableStateOf<List<LayoutSuggester.Suggestion>?>(null)
        private set

    /** Размер холста в пикселях; обычное поле, не состояние (нужно только для fit/жестов). */
    var canvasSize: Size = Size.Zero

    // ---------- производные ----------

    val layout: LayoutResult by derivedStateOf { TilingEngine.build(room, tile, pattern) }

    /** Индексы декоративных плиток текущей раскладки. */
    val decorIdx: Set<Int> by derivedStateOf {
        DecorPlanner.select(layout, tile, decor, roomCenter())
    }

    /** Перекрытие декора мебелью и плитки под ней. */
    val coverage: CoverageReport by derivedStateOf {
        CoverageAnalyzer.analyze(layout, tile, decorIdx, decor.art, furniture)
    }

    /** Подрезка по каждой стене + предупреждения. */
    val cutReport: CutReport by derivedStateOf { CutAnalyzer.analyze(room, tile, layout) }

    fun roomCenter(): Pt {
        val pts = room.points
        if (pts.isEmpty()) return Pt(0.0, 0.0)
        return Pt(
            (pts.minOf { it.x } + pts.maxOf { it.x }) / 2,
            (pts.minOf { it.y } + pts.maxOf { it.y }) / 2,
        )
    }

    val buyCount: Int get() = ceil(layout.totalCount * (1 + reservePct / 100.0)).toInt()

    val buyM2: Double get() = buyCount * tile.widthMm * tile.heightMm / 1e6

    // ---------- история изменений ----------

    private data class Snap(
        val room: RoomSpec,
        val tile: TileSpec,
        val pattern: PatternSpec,
        val tileColor: Color,
        val variation: Boolean,
        val reservePct: Int,
        val decor: DecorSpec,
        val anchor: AnchorMode,
        val furniture: List<Furniture>,
        val finishes: Map<String, Finish>,
        val openings: Map<String, List<Cutout>>,
        val wallHeightM: Double,
        val rooms: List<RoomDto>,
        val activeRoom: Int,
    )

    private val undoStack = ArrayDeque<Snap>()
    private val redoStack = ArrayDeque<Snap>()

    var canUndo by mutableStateOf(false)
        private set

    var canRedo by mutableStateOf(false)
        private set

    private fun snap() = Snap(
        room, tile, pattern, tileColor, variation, reservePct,
        decor, anchor, furniture, finishes, openings, wallHeightM,
        rooms, activeRoom,
    )

    /** Запомнить состояние перед изменением. */
    fun pushUndo() {
        undoStack.addLast(snap())
        if (undoStack.size > 40) undoStack.removeFirst()
        redoStack.clear()
        canUndo = true
        canRedo = false
    }

    private fun restore(s: Snap) {
        room = s.room
        tile = s.tile
        pattern = s.pattern
        tileColor = s.tileColor
        variation = s.variation
        reservePct = s.reservePct
        decor = s.decor
        anchor = s.anchor
        furniture = s.furniture
        finishes = s.finishes
        openings = s.openings
        wallHeightM = s.wallHeightM
        rooms = s.rooms
        activeRoom = s.activeRoom
        selection = null
        suggestions = null
    }

    fun undo() {
        val s = undoStack.removeLastOrNull() ?: return
        redoStack.addLast(snap())
        restore(s)
        canUndo = undoStack.isNotEmpty()
        canRedo = true
    }

    fun redo() {
        val s = redoStack.removeLastOrNull() ?: return
        undoStack.addLast(snap())
        restore(s)
        canRedo = redoStack.isNotEmpty()
        canUndo = true
    }

    // ---------- преобразования координат ----------

    fun toWorld(o: Offset): Pt = Pt(
        ((o.x - view.offset.x) / view.scale).toDouble(),
        ((o.y - view.offset.y) / view.scale).toDouble(),
    )

    fun toScreen(p: Pt): Offset = Offset(
        (p.x * view.scale + view.offset.x).toFloat(),
        (p.y * view.scale + view.offset.y).toFloat(),
    )

    private var didInitialFit = false

    fun maybeInitialFit() {
        if (!didInitialFit && canvasSize.width > 0f && canvasSize.height > 0f) {
            didInitialFit = true
            fit()
        }
    }

    /** Вписать план комнаты в холст. */
    fun fit() {
        if (canvasSize.width <= 0f || canvasSize.height <= 0f || room.points.isEmpty()) return
        val allPts = room.points +
            rooms.filterIndexed { i, _ -> i != activeRoom }.flatMap { it.spec.points }
        val minx = allPts.minOf { it.x }
        val maxx = allPts.maxOf { it.x }
        val miny = allPts.minOf { it.y }
        val maxy = allPts.maxOf { it.y }
        val bw = max(0.5, maxx - minx)
        val bh = max(0.5, maxy - miny)
        val s = max(
            12f,
            min(
                ((canvasSize.width - 76f) / bw).toFloat(),
                ((canvasSize.height - 96f) / bh).toFloat(),
            ),
        )
        val ox = canvasSize.width / 2f - ((minx + maxx) / 2 * s).toFloat()
        val oy = canvasSize.height / 2f - ((miny + maxy) / 2 * s).toFloat()
        view = ViewTransform(s, Offset(ox, oy))
    }

    // ---------- жесты ----------

    private enum class Drag { NONE, PAN, PATTERN, VERTEX, CUT_MOVE, CUT_RESIZE, FURN_MOVE, FURN_RESIZE }

    private var drag = Drag.NONE
    private var dragIndex = -1
    private var grabDx = 0.0
    private var grabDy = 0.0

    fun gestureDown(pos: Offset) {
        hintVisible = false
        drag = Drag.NONE
        dragIndex = -1
        val w = toWorld(pos)
        // тап по другой комнате квартиры переключает на неё (в любом режиме)
        if (!pointInPolygon(w, room.points)) {
            rooms.forEachIndexed { i, r ->
                if (i != activeRoom && pointInPolygon(w, r.spec.points)) {
                    switchRoom(i)
                    return
                }
            }
        }
        if (!roomMode) {
            drag = if (pointInPolygon(w, room.points)) Drag.PATTERN else Drag.PAN
            return
        }

        // 1. вершина
        room.points.forEachIndexed { i, p ->
            if (drag == Drag.NONE && (toScreen(p) - pos).getDistance() < 26f * uiScale) {
                drag = Drag.VERTEX
                dragIndex = i
                selection = Selection.Vertex(i)
            }
        }
        if (drag != Drag.NONE) return

        // 2. «+» на середине ребра
        val pts = room.points
        for (i in pts.indices) {
            val a = pts[i]
            val b = pts[(i + 1) % pts.size]
            val sa = toScreen(a)
            val sb = toScreen(b)
            if ((sb - sa).getDistance() < 56f * uiScale) continue
            val mid = Offset((sa.x + sb.x) / 2f, (sa.y + sb.y) / 2f)
            if ((mid - pos).getDistance() < 22f * uiScale) {
                val np = Pt((a.x + b.x) / 2, (a.y + b.y) / 2)
                val list = pts.toMutableList()
                list.add(i + 1, np)
                room = room.copy(points = list)
                drag = Drag.VERTEX
                dragIndex = i + 1
                selection = Selection.Vertex(i + 1)
                return
            }
        }

        // 3. ручка выреза (правый нижний угол)
        room.cutouts.forEachIndexed { i, c ->
            if (drag == Drag.NONE &&
                (toScreen(Pt(c.x + c.w, c.y + c.h)) - pos).getDistance() < 26f * uiScale
            ) {
                drag = Drag.CUT_RESIZE
                dragIndex = i
                selection = Selection.Cut(i)
            }
        }
        if (drag != Drag.NONE) return

        // 4. тело выреза
        room.cutouts.forEachIndexed { i, c ->
            if (drag == Drag.NONE &&
                w.x > c.x && w.x < c.x + c.w && w.y > c.y && w.y < c.y + c.h
            ) {
                drag = Drag.CUT_MOVE
                dragIndex = i
                grabDx = w.x - c.x
                grabDy = w.y - c.y
                selection = Selection.Cut(i)
            }
        }
        if (drag != Drag.NONE) return

        // 5. мебель: угловая ручка и перенос
        furniture.forEachIndexed { i, f ->
            if (drag == Drag.NONE &&
                (toScreen(Pt(f.x + f.w, f.y + f.h)) - pos).getDistance() < 26f * uiScale
            ) {
                drag = Drag.FURN_RESIZE
                dragIndex = i
                selection = Selection.Furn(i)
            }
        }
        if (drag != Drag.NONE) return
        furniture.forEachIndexed { i, f ->
            if (drag == Drag.NONE && w.x > f.x && w.x < f.x + f.w && w.y > f.y && w.y < f.y + f.h) {
                drag = Drag.FURN_MOVE
                dragIndex = i
                grabDx = w.x - f.x
                grabDy = w.y - f.y
                selection = Selection.Furn(i)
            }
        }
        if (drag != Drag.NONE) return

        // 6. панорамирование
        drag = Drag.PAN
        selection = null
    }

    private var gestureSnapped = false

    fun gestureMove(pos: Offset, prev: Offset) {
        if (!gestureSnapped && drag != Drag.NONE && drag != Drag.PAN) {
            gestureSnapped = true
            pushUndo()
        }
        val d = pos - prev
        when (drag) {
            Drag.PAN -> view = view.copy(offset = view.offset + d)

            Drag.PATTERN -> {
                anchor = AnchorMode.FREE
                pattern = pattern.copy(
                offsetX = pattern.offsetX + d.x / view.scale,
                    offsetY = pattern.offsetY + d.y / view.scale,
                )
            }

            Drag.VERTEX -> {
                val pts = room.points.toMutableList()
                if (dragIndex in pts.indices) {
                    pts[dragIndex] = snapVertex(dragIndex, toWorld(pos))
                    room = room.copy(points = pts)
                }
            }

            Drag.CUT_MOVE -> {
                val cs = room.cutouts.toMutableList()
                if (dragIndex in cs.indices) {
                    val w = toWorld(pos)
                    val c = cs[dragIndex]
                    cs[dragIndex] = c.copy(x = round2(w.x - grabDx), y = round2(w.y - grabDy))
                    room = room.copy(cutouts = cs)
                }
            }

            Drag.CUT_RESIZE -> {
                val cs = room.cutouts.toMutableList()
                if (dragIndex in cs.indices) {
                    val w = toWorld(pos)
                    val c = cs[dragIndex]
                    cs[dragIndex] = c.copy(
                        w = max(0.1, round2(w.x - c.x)),
                        h = max(0.1, round2(w.y - c.y)),
                    )
                    room = room.copy(cutouts = cs)
                }
            }

            Drag.FURN_MOVE -> {
                val fs = furniture.toMutableList()
                if (dragIndex in fs.indices) {
                    val w = toWorld(pos)
                    val f = fs[dragIndex]
                    fs[dragIndex] = f.copy(x = round2(w.x - grabDx), y = round2(w.y - grabDy))
                    furniture = fs
                }
            }

            Drag.FURN_RESIZE -> {
                val fs = furniture.toMutableList()
                if (dragIndex in fs.indices) {
                    val w = toWorld(pos)
                    val f = fs[dragIndex]
                    fs[dragIndex] = f.copy(
                        w = max(0.2, round2(w.x - f.x)),
                        h = max(0.2, round2(w.y - f.y)),
                    )
                    furniture = fs
                }
            }

            Drag.NONE -> Unit
        }
    }

    fun gestureEnd() {
        gestureSnapped = false
        drag = Drag.NONE
        dragIndex = -1
    }

    /** Прервать текущий жест (например, при переходе к двупальцевому зуму). */
    fun cancelGesture() {
        gestureSnapped = false
        drag = Drag.NONE
        dragIndex = -1
    }

    /** Зум двумя пальцами: мировая точка под mid0 остаётся под mid. */
    fun pinch(base: ViewTransform, d0: Float, mid0: Offset, d: Float, mid: Offset) {
        if (d0 <= 0f) return
        val s = (base.scale * (d / d0)).coerceIn(12f, 2400f)
        val wx = (mid0.x - base.offset.x) / base.scale
        val wy = (mid0.y - base.offset.y) / base.scale
        view = ViewTransform(s, Offset(mid.x - wx * s, mid.y - wy * s))
    }

    private fun round2(v: Double) = Math.round(v * 100.0) / 100.0

    /** Округление до сантиметра + прилипание к координатам соседних вершин. */
    private fun snapVertex(i: Int, w: Pt): Pt {
        val pts = room.points
        var x = round2(w.x)
        var y = round2(w.y)
        val tol = 10.0 / view.scale
        val neighbours = listOf(pts[(i - 1 + pts.size) % pts.size], pts[(i + 1) % pts.size])
        for (n in neighbours) {
            if (abs(x - n.x) < tol) x = n.x
            if (abs(y - n.y) < tol) y = n.y
        }
        return Pt(x, y)
    }

    // ---------- плитка и узор ----------

    fun setTileWidth(mm: Double) { tile = tile.copy(widthMm = mm); reanchor() }

    fun setTileHeight(mm: Double) { tile = tile.copy(heightMm = mm); reanchor() }

    fun setGrout(mm: Double) { tile = tile.copy(groutMm = mm); reanchor() }

    fun setPatternType(t: PatternType) {
        pushUndo()
        pattern = pattern.copy(type = t)
        suggestions = null
        reanchor()
    }

    fun setRotation(deg: Double) { pattern = pattern.copy(rotationDeg = deg); reanchor() }

    // ---------- декор и точка отсчёта ----------

    /** Пересчитать смещение узора под выбранную точку отсчёта. */
    fun reanchor() {
        if (anchor != AnchorMode.FREE) {
            pattern = Aligner.applyAnchor(pattern, room.points, tile, anchor, decor.art)
        }
    }

    fun switchAnchor(a: AnchorMode) { anchor = a; reanchor() }

    fun setDecorMode(m: DecorMode) {
        pushUndo()
        decor = decor.copy(mode = m)
        if (m != DecorMode.NONE && anchor == AnchorMode.FREE) anchor = AnchorMode.ART_CENTER
        reanchor()
    }

    fun setArt(a: ArtRect) {
        decor = decor.copy(
            art = ArtRect(
                a.x.coerceIn(0.0, 0.9),
                a.y.coerceIn(0.0, 0.9),
                a.w.coerceIn(0.1, 1.0 - a.x.coerceIn(0.0, 0.9)),
                a.h.coerceIn(0.1, 1.0 - a.y.coerceIn(0.0, 0.9)),
            )
        )
        reanchor()
    }

    fun setPanel(cols: Int, rows: Int) { decor = decor.copy(panelCols = cols, panelRows = rows) }

    fun loadDecorImage(context: Context, uri: Uri) {
        viewModelScope.launch {
            val bmp = withContext(Dispatchers.IO) { decodeBitmap(context, uri) }
            if (bmp != null) decorImage = bmp
        }
    }

    fun clearDecorImage() { decorImage = null }

    fun resetShift() { pattern = pattern.copy(offsetX = 0.0, offsetY = 0.0) }

    fun setColor(c: Color) { tileColor = c; tileImage = null }

    fun toggleVariation() { variation = !variation }

    fun clearImage() { tileImage = null }

    private fun decodeBitmap(context: Context, uri: Uri): ImageBitmap? = runCatching {
        if (Build.VERSION.SDK_INT >= 28) {
            ImageDecoder.decodeBitmap(
                ImageDecoder.createSource(context.contentResolver, uri)
            ) { decoder, _, _ -> decoder.isMutableRequired = false }
        } else {
            @Suppress("DEPRECATION")
            MediaStore.Images.Media.getBitmap(context.contentResolver, uri)
        }
    }.getOrNull()?.asImageBitmap()

    fun loadTileImage(context: Context, uri: Uri) {
        viewModelScope.launch {
            val bmp = withContext(Dispatchers.IO) { decodeBitmap(context, uri) }
            if (bmp != null) tileImage = bmp
        }
    }

    // ---------- комната ----------

    fun applyRect(wM: Double, hM: Double) {
        pushUndo()
        room = RoomSpec(
            listOf(Pt(0.0, 0.0), Pt(wM, 0.0), Pt(wM, hM), Pt(0.0, hM)),
            room.cutouts.filter { it.x + it.w <= wM && it.y + it.h <= hM },
        )
        selection = null
        suggestions = null
        reanchor()
        fit()
    }

    fun applyLShape() {
        pushUndo()
        room = RoomSpec(
            listOf(
                Pt(0.0, 0.0), Pt(4.0, 0.0), Pt(4.0, 1.8),
                Pt(2.2, 1.8), Pt(2.2, 3.0), Pt(0.0, 3.0),
            ),
            emptyList(),
        )
        selection = null
        suggestions = null
        reanchor()
        fit()
    }

    fun addCutout() {
        pushUndo()
        val pts = room.points
        val cx = pts.sumOf { it.x } / pts.size
        val cy = pts.sumOf { it.y } / pts.size
        val cs = room.cutouts + Cutout(round2(cx - 0.4), round2(cy - 0.4), 0.8, 0.8)
        room = room.copy(cutouts = cs)
        roomMode = true
        selection = Selection.Cut(cs.lastIndex)
    }

    fun deleteSelectedVertex() {
        pushUndo()
        val sel = selection as? Selection.Vertex ?: return
        if (room.points.size <= 3) return
        val pts = room.points.toMutableList()
        if (sel.i !in pts.indices) return
        pts.removeAt(sel.i)
        room = room.copy(points = pts)
        selection = null
    }

    fun deleteSelectedCutout() {
        pushUndo()
        val sel = selection as? Selection.Cut ?: return
        val cs = room.cutouts.toMutableList()
        if (sel.i !in cs.indices) return
        cs.removeAt(sel.i)
        room = room.copy(cutouts = cs)
        selection = null
    }

    fun setSelectedCutW(m: Double) = updateSelectedCut { it.copy(w = max(0.1, m)) }

    fun setSelectedCutH(m: Double) = updateSelectedCut { it.copy(h = max(0.1, m)) }

    private fun updateSelectedCut(f: (Cutout) -> Cutout) {
        val sel = selection as? Selection.Cut ?: return
        val cs = room.cutouts.toMutableList()
        if (sel.i !in cs.indices) return
        cs[sel.i] = f(cs[sel.i])
        room = room.copy(cutouts = cs)
    }

    // ---------- цены и логотип ----------

    fun updatePrices(transform: (Prices) -> Prices) { prices = transform(prices) }

    private val logoFile: File
        get() = File(getApplication<Application>().filesDir, "logo.png")

    init {
        viewModelScope.launch {
            masterLogo = withContext(Dispatchers.IO) { decodeLogoFile() }
        }
    }

    private fun decodeLogoFile(): ImageBitmap? = runCatching {
        android.graphics.BitmapFactory.decodeFile(logoFile.absolutePath)?.asImageBitmap()
    }.getOrNull()

    fun loadMasterLogo(context: Context, uri: Uri) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                runCatching {
                    context.contentResolver.openInputStream(uri)?.use { input ->
                        logoFile.outputStream().use { out -> input.copyTo(out) }
                    }
                }
            }
            masterLogo = withContext(Dispatchers.IO) { decodeLogoFile() }
        }
    }

    fun loadFitPhoto(context: Context, uri: Uri) {
        viewModelScope.launch {
            val bmp = withContext(Dispatchers.IO) { decodeBitmap(context, uri) }
            if (bmp != null) fitPhoto = bmp
        }
    }

    fun clearFitPhoto() { fitPhoto = null }

    fun moveFitCorner(i: Int, pos: Offset) {
        if (i !in 0..3) return
        val q = fitQuad.toMutableList()
        q[i] = Offset(pos.x.coerceIn(0f, 1f), pos.y.coerceIn(0f, 1f))
        fitQuad = q
    }

    fun resetFitQuad() {
        fitQuad = listOf(Offset(0.16f, 0.34f), Offset(0.84f, 0.34f), Offset(0.97f, 0.93f), Offset(0.03f, 0.93f))
    }

    fun updateFitAlpha(a: Float) { fitAlpha = a.coerceIn(0.3f, 1f) }

    /** Живой AR: раскладка рисуется в картинку и передаётся ARCore-экрану. */
    fun openAr(context: Context) {
        viewModelScope.launch {
            val result = withContext(Dispatchers.Default) {
                renderFloorBitmap(
                    points = room.points,
                    tiles = layout.tiles,
                    decorIdx = decorIdx,
                    tileBmp = tileImage?.asAndroidBitmap(),
                    decorBmp = (decorImage ?: tileImage)?.asAndroidBitmap(),
                    colorArgb = tileColor.toArgb(),
                    variation = variation,
                )
            }
            ArBridge.floorBitmap = result.first
            ArBridge.widthM = result.second
            ArBridge.heightM = result.third
            context.startActivity(Intent(context, ArActivity::class.java))
        }
    }

    fun clearMasterLogo() {
        masterLogo = null
        viewModelScope.launch(Dispatchers.IO) { runCatching { logoFile.delete() } }
    }

    /** Стоимость каждой отделанной поверхности: материалы и работа по текущим ценам. */
    fun surfaceCosts(): List<SurfaceCost> {
        val p = prices
        val tileAreaM2 = tile.widthMm * tile.heightMm / 1_000_000.0
        return model.surfaces.mapNotNull { su ->
            val fin = finishOf(su.id)
            if (fin == Finish.NONE) return@mapNotNull null
            val area = surfaceAreaM2(su.id)
            if (area <= 0.0) return@mapNotNull null
            var mat = 0.0
            var work = 0.0
            when (fin) {
                Finish.TILE -> {
                    val lay = surfaceLayout(su.id)
                    val pieces = ceil(lay.totalCount * (1 + reservePct / 100.0)).toInt()
                    val tileCost = if (p.tilePc > 0) pieces * p.tilePc else pieces * tileAreaM2 * p.tileM2
                    mat = tileCost + MaterialCalc.tileAdhesiveKg(area, tile) * p.adhesiveKg
                    work = area * p.workTileM2
                }

                Finish.WALLPAPER -> {
                    val wall = model.walls.firstOrNull { it.id == su.id }
                    val w = wall?.lengthM ?: sqrt(area)
                    val h = if (wall != null) wallHeightM else sqrt(area)
                    mat = MaterialCalc.wallpaper(w, h).rolls * p.roll
                    work = area * p.workWallM2
                }

                Finish.PAINT -> {
                    mat = MaterialCalc.paintLiters(area, 2) * p.paintL
                    work = area * p.workPaintM2
                }

                else -> Unit
            }
            SurfaceCost(su.id, fin, area, mat, work)
        }
    }

    // ---------- мебель ----------

    fun addFurniture(name: String, wM: Double, hM: Double, heightM: Double = 0.85, kind: String = "box") {
        pushUndo()
        val c = roomCenter()
        val f = Furniture(
            id = "f" + System.currentTimeMillis(),
            name = name,
            heightM = heightM,
            kind = kind,
            x = round2(c.x - wM / 2),
            y = round2(c.y - hM / 2),
            w = wM,
            h = hM,
        )
        furniture = furniture + f
        roomMode = true
        selection = Selection.Furn(furniture.lastIndex)
    }

    fun deleteSelectedFurniture() {
        pushUndo()
        val sel = selection as? Selection.Furn ?: return
        val fs = furniture.toMutableList()
        if (sel.i !in fs.indices) return
        fs.removeAt(sel.i)
        furniture = fs
        selection = null
    }

    fun setSelectedFurnW(m: Double) = updateSelectedFurn { it.copy(w = max(0.2, m)) }

    fun setSelectedFurnH(m: Double) = updateSelectedFurn { it.copy(h = max(0.2, m)) }

    fun toggleSelectedFurnCover() = updateSelectedFurn { it.copy(coversFinish = !it.coversFinish) }

    /** Повернуть объект на 90°: меняем ширину и глубину местами. */
    fun rotateSelectedFurn() = updateSelectedFurn { it.copy(w = it.h, h = it.w) }

    private fun updateSelectedFurn(f: (Furniture) -> Furniture) {
        val sel = selection as? Selection.Furn ?: return
        val fs = furniture.toMutableList()
        if (sel.i !in fs.indices) return
        fs[sel.i] = f(fs[sel.i])
        furniture = fs
    }

    /** Повернуть плитку на 90°: меняем ширину и длину местами. */
    fun rotateTile() {
        pushUndo()
        tile = tile.copy(widthMm = tile.heightMm, heightMm = tile.widthMm)
        reanchor()
    }

    // ---------- режимы и слои ----------

    fun setReserve(p: Int) { reservePct = p }

    fun switchRoomMode(b: Boolean) { roomMode = b; if (!b) selection = null }

    fun toggleDims() { showDims = !showDims }

    fun toggleCuts() { showCuts = !showCuts }

    fun toggleFurniture() { showFurniture = !showFurniture }

    fun toggleArt() { showArt = !showArt }

    fun setWallHeight(m: Double) { wallHeightM = m.coerceIn(1.8, 4.0) }

    // ---------- поверхности ----------

    /** Модель комнаты: пол, стены по контуру, потолок. */
    val model: RoomModel by derivedStateOf {
        RoomModel.fromFloor(room.points, wallHeightM, room.cutouts)
    }

    fun finishOf(id: String): Finish = finishes[id]
        ?: if (id == "floor") Finish.TILE else Finish.PAINT

    fun setFinish(id: String, f: Finish) {
        pushUndo()
        finishes = finishes + (id to f)
    }

    fun selectSurface(id: String) { activeSurface = id }

    fun openingsOf(id: String): List<Cutout> = openings[id] ?: emptyList()

    /** Добавить проём по центру стены: окно поднято над полом, дверь стоит на полу. */
    fun addOpening(id: String, wM: Double, hM: Double, fromFloorM: Double) {
        pushUndo()
        val wall = model.walls.firstOrNull { it.id == id } ?: return
        val x = ((wall.lengthM - wM) / 2).coerceAtLeast(0.0)
        val y = fromFloorM.coerceIn(0.0, (wallHeightM - hM).coerceAtLeast(0.0))
        openings = openings + (id to (openingsOf(id) + Cutout(round2(x), round2(y), wM, hM)))
    }

    fun deleteOpening(id: String, index: Int) {
        pushUndo()
        val list = openingsOf(id).toMutableList()
        if (index !in list.indices) return
        list.removeAt(index)
        openings = openings + (id to list)
    }

    /** Площадь поверхности за вычетом проёмов. */
    fun surfaceAreaM2(id: String): Double {
        val s = model.surfaces.firstOrNull { it.id == id } ?: return 0.0
        val holes = if (s.kind == SurfaceKind.WALL) openingsOf(id).sumOf { it.w * it.h } else 0.0
        return (s.areaM2() - holes).coerceAtLeast(0.0)
    }

    /** Раскладка плитки для стены или потолка (с учётом проёмов). */
    fun surfaceLayout(id: String): LayoutResult {
        val s = model.surfaces.firstOrNull { it.id == id } ?: return TilingEngine.build(room, tile, pattern)
        val spec = RoomSpec(s.outline, if (s.kind == SurfaceKind.WALL) openingsOf(id) else s.holes)
        return TilingEngine.build(spec, tile, pattern)
    }

    // ---------- советы ----------

    fun runSuggest() {
        viewModelScope.launch {
            val s = withContext(Dispatchers.Default) {
                LayoutSuggester.suggest(room, tile, pattern)
            }
            suggestions = s
        }
    }

    fun applySuggestion(s: LayoutSuggester.Suggestion) {
        pattern = pattern.copy(type = s.type, rotationDeg = s.rotationDeg)
        suggestions = null
    }

    // ---------- проекты ----------

    private fun toast(resId: Int) {
        Toast.makeText(getApplication(), getApplication<Application>().getString(resId), Toast.LENGTH_SHORT).show()
    }

    fun refreshProjects() {
        viewModelScope.launch {
            projects = withContext(Dispatchers.IO) { repo.list() }
        }
    }

    fun saveProject() {
        syncActiveRoom()
        val n = projectName.ifBlank { getApplication<Application>().getString(R.string.default_name) }
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                repo.save(
                    ProjectDto(
                        name = n,
                        room = room,
                        tile = tile,
                        pattern = pattern,
                        colorArgb = tileColor.toArgb(),
                        variation = variation,
                        reservePct = reservePct,
                        decor = decor,
                        anchor = anchor,
                        furniture = furniture,
                        finishes = finishes,
                        openings = openings,
                        wallHeightM = wallHeightM,
                        prices = prices,
                        rooms = rooms,
                        activeRoom = activeRoom,
                        savedAt = System.currentTimeMillis(),
                    )
                )
            }
            projectName = n
            refreshProjects()
            toast(R.string.saved)
        }
    }

    fun loadProject(name: String) {
        viewModelScope.launch {
            val dto = withContext(Dispatchers.IO) { repo.load(name) } ?: return@launch
            room = dto.room
            tile = dto.tile
            pattern = dto.pattern
            tileColor = Color(dto.colorArgb)
            tileImage = null
            variation = dto.variation
            reservePct = dto.reservePct
            decor = dto.decor
            anchor = dto.anchor
            furniture = dto.furniture
            finishes = dto.finishes
            openings = dto.openings
            wallHeightM = dto.wallHeightM
            prices = dto.prices
            if (dto.rooms.isNotEmpty()) {
                rooms = dto.rooms
                activeRoom = dto.activeRoom.coerceIn(0, dto.rooms.lastIndex)
                applyRoom(rooms[activeRoom])
            } else {
                rooms = listOf(snapshotRoom(""))
                activeRoom = 0
            }
            projectName = dto.name
            selection = null
            suggestions = null
            fit()
            toast(R.string.loaded)
        }
    }

    fun deleteProject(name: String) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { repo.delete(name) }
            if (projectName == name) projectName = ""
            refreshProjects()
            toast(R.string.deleted)
        }
    }
}
