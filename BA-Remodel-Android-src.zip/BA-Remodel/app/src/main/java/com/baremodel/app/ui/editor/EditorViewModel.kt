package com.baremodel.app.ui.editor

import android.app.Application
import android.content.Context
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.widget.Toast
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.toArgb
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.baremodel.app.R
import android.content.Intent
import androidx.compose.ui.graphics.asAndroidBitmap
import com.baremodel.app.ar.ArActivity
import com.baremodel.app.ar.ArBridge
import com.baremodel.app.ar.ExtraLayer
import com.baremodel.app.ar.PanelInfo
import com.baremodel.app.ar.renderFloorBitmap
import com.baremodel.app.data.Prices
import com.baremodel.app.data.RoomDto
import com.baremodel.app.data.ZoneDto
import java.io.File
import com.baremodel.app.data.ProjectDto
import com.baremodel.app.data.ProjectMeta
import com.baremodel.app.data.ProjectRepository
import com.baremodel.core.Aligner
import com.baremodel.core.AnchorMode
import com.baremodel.core.ArtRect
import com.baremodel.core.CutAnalyzer
import com.baremodel.core.CutReport
import com.baremodel.core.CoverageAnalyzer
import com.baremodel.core.CoverageReport
import com.baremodel.core.Cutout
import com.baremodel.core.Furniture
import com.baremodel.core.DecorMode
import com.baremodel.core.DecorPlanner
import com.baremodel.core.DecorSpec
import com.baremodel.core.Finish
import com.baremodel.core.RoomModel
import com.baremodel.core.SurfaceKind
import com.baremodel.core.LayoutResult
import com.baremodel.core.LayoutSuggester
import com.baremodel.core.MaterialCalc
import com.baremodel.core.areaM2
import com.baremodel.core.PatternSpec
import com.baremodel.core.PlacedTile
import com.baremodel.core.PatternType
import com.baremodel.core.Pt
import com.baremodel.core.RoomSpec
import com.baremodel.core.TileClass
import com.baremodel.core.TileSpec
import com.baremodel.core.TilingEngine
import com.baremodel.core.clipPolygonByQuad
import com.baremodel.core.clipPolygonByRect
import com.baremodel.core.pointInPolygon
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.util.Locale
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

/** Экранное преобразование: метры → пиксели. */
data class ViewTransform(val scale: Float = 110f, val offset: Offset = Offset(40f, 60f))

/** Строка сводки по комнате квартиры (для отчёта и PDF). */
data class RoomStat(
    val name: String,
    val areaM2: Double,
    val buy: Int,
    val money: Double,
    val tileLabel: String,
)

sealed interface Selection {
    data class Zone(val i: Int) : Selection
    data class Vertex(val i: Int) : Selection
    data class Cut(val i: Int) : Selection
    data class Furn(val i: Int) : Selection
    data class Tile(val i: Int) : Selection
}

private fun crossZ(ox: Double, oy: Double, ax: Double, ay: Double, bx: Double, by: Double): Double =
    (ax - ox) * (by - oy) - (ay - oy) * (bx - ox)

private fun segsCross(p1: Pt, p2: Pt, p3: Pt, p4: Pt): Boolean {
    val d1 = crossZ(p3.x, p3.y, p4.x, p4.y, p1.x, p1.y)
    val d2 = crossZ(p3.x, p3.y, p4.x, p4.y, p2.x, p2.y)
    val d3 = crossZ(p1.x, p1.y, p2.x, p2.y, p3.x, p3.y)
    val d4 = crossZ(p1.x, p1.y, p2.x, p2.y, p4.x, p4.y)
    return ((d1 > 1e-9 && d2 < -1e-9) || (d1 < -1e-9 && d2 > 1e-9)) &&
        ((d3 > 1e-9 && d4 < -1e-9) || (d3 < -1e-9 && d4 > 1e-9))
}

/**
 * Пересекаются ли контуры по площади. Касание рёбрами и общими углами не считается:
 * вершины проверяются с миллиметровым сдвигом к центру своей комнаты, поэтому комнаты
 * можно ставить вплотную стена к стене.
 */
fun polygonsOverlap(a: List<Pt>, b: List<Pt>): Boolean {
    if (a.size < 3 || b.size < 3) return false
    for (i in a.indices) {
        for (j in b.indices) {
            if (segsCross(a[i], a[(i + 1) % a.size], b[j], b[(j + 1) % b.size])) return true
        }
    }
    val ca = Pt(a.sumOf { it.x } / a.size, a.sumOf { it.y } / a.size)
    if (a.any { pointInPolygon(Pt(it.x + (ca.x - it.x) * 0.001, it.y + (ca.y - it.y) * 0.001), b) }) return true
    val cb = Pt(b.sumOf { it.x } / b.size, b.sumOf { it.y } / b.size)
    if (b.any { pointInPolygon(Pt(it.x + (cb.x - it.x) * 0.001, it.y + (cb.y - it.y) * 0.001), a) }) return true
    return false
}

/** Стоимость поверхности: материалы и работа. */

data class SurfaceCost(
    val id: String,
    val finish: Finish,
    val areaM2: Double,
    val materials: Double,
    val work: Double,
)

class EditorViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = ProjectRepository(app)

    // ---------- состояние ----------

    var room by mutableStateOf(
        RoomSpec(listOf(Pt(0.0, 0.0), Pt(4.0, 0.0), Pt(4.0, 3.0), Pt(0.0, 3.0)))
    )
        private set

    var tile by mutableStateOf(TileSpec(600.0, 600.0, 3.0))
        private set

    var pattern by mutableStateOf(PatternSpec())
        private set

    var tileColor by mutableStateOf(Color(0xFFC7CCD6))
        private set

    var variation by mutableStateOf(true)
        private set

    var tileImage by mutableStateOf<ImageBitmap?>(null)
        private set

    var decor by mutableStateOf(DecorSpec())
        private set

    var anchor by mutableStateOf(AnchorMode.FREE)
        private set

    var decorImage by mutableStateOf<ImageBitmap?>(null)
        private set

    var furniture by mutableStateOf<List<Furniture>>(emptyList())
        private set

    var reservePct by mutableStateOf(10)
        private set

    var roomMode by mutableStateOf(false)
        private set

    var showDims by mutableStateOf(true)
        private set

    var showCuts by mutableStateOf(true)
        private set

    var showFurniture by mutableStateOf(true)
        private set

    /** Показ области рисунка на каждой плитке плана. */
    var showArt by mutableStateOf(false)
        private set

    var wallHeightM by mutableStateOf(2.7)
        private set

    // ---------- квартира: несколько комнат ----------

    /** Все комнаты квартиры; запись активной обновляется при переключении и сохранении. */
    var rooms by mutableStateOf(listOf<RoomDto>())
        private set

    var activeRoom by mutableStateOf(0)
        private set

    /** Снимок текущих полей как комната. */
    private fun snapshotRoom(name: String): RoomDto = RoomDto(
        name = name,
        decorOverrides = decorOverrides,
        panelOn = panelOn,
        panelRX = panelRX,
        panelRY = panelRY,
        zones = zones,
        tileColors = tileColors,
        spec = room,
        tile = tile,
        pattern = pattern,
        colorArgb = tileColor.toArgb(),
        variation = variation,
        decor = decor,
        anchor = anchor,
        finishes = finishes,
        openings = openings,
    )

    private fun applyRoom(d: RoomDto) {
        decorOverrides = d.decorOverrides
        panelOn = d.panelOn
        panelRX = d.panelRX
        panelRY = d.panelRY
        zones = d.zones
        tileColors = d.tileColors
        activeZone = -1
        room = d.spec
        tile = d.tile
        pattern = d.pattern
        if (d.colorArgb != -1) tileColor = Color(d.colorArgb)
        variation = d.variation
        decor = d.decor
        anchor = d.anchor
        finishes = d.finishes
        openings = d.openings
        selection = null
        suggestions = null
        reanchor()
    }

    /** Обновить запись активной комнаты в списке. */
    fun syncActiveRoom() {
        val list = rooms.toMutableList()
        if (activeRoom in list.indices) {
            val snap = snapshotRoom(list[activeRoom].name)
            if (list[activeRoom] != snap) {
                list[activeRoom] = snap
                rooms = list
            }
        } else if (list.isEmpty()) {
            rooms = listOf(snapshotRoom(""))
            activeRoom = 0
        }
    }

    fun switchRoom(i: Int) {
        if (i == activeRoom || i !in rooms.indices) return
        pushUndo()
        syncActiveRoom()
        activeRoom = i
        applyRoom(rooms[i])
    }

    /** Новая комната справа от габарита квартиры, наследует плитку и узор текущей. */
    fun addRoom() {
        pushUndo()
        syncActiveRoom()
        val all = rooms.flatMap { it.spec.points } + room.points
        val maxX = all.maxOf { it.x }
        val minY = all.minOf { it.y }
        val x0 = round2(maxX + 0.4)
        val y0 = round2(minY)
        val spec = RoomSpec(
            listOf(Pt(x0, y0), Pt(x0 + 3.0, y0), Pt(x0 + 3.0, y0 + 2.4), Pt(x0, y0 + 2.4)),
        )
        val d = snapshotRoom("").copy(
            spec = spec,
            decor = DecorSpec(),
            anchor = AnchorMode.FREE,
            finishes = emptyMap(),
            openings = emptyMap(),
        )
        rooms = rooms + d
        activeRoom = rooms.lastIndex
        applyRoom(d)
        fit()
    }

    fun deleteActiveRoom() {
        if (rooms.size <= 1) return
        pushUndo()
        val list = rooms.toMutableList()
        list.removeAt(activeRoom)
        rooms = list
        activeRoom = activeRoom.coerceAtMost(list.lastIndex)
        applyRoom(list[activeRoom])
        fit()
    }

    /**
     * Насколько сдвинуть активную комнату, чтобы она встала вплотную к соседней.
     * Сравниваются габариты: край к краю по X и по Y, порог 12 см.
     */
    private fun snapOffset(): Pt? {
        if (rooms.size < 2 || room.points.isEmpty()) return null
        val ax0 = room.points.minOf { it.x }
        val ax1 = room.points.maxOf { it.x }
        val ay0 = room.points.minOf { it.y }
        val ay1 = room.points.maxOf { it.y }
        var bestX = 0.0
        var bestY = 0.0
        // порог тем больше, чем толще стена: иначе «подвёл вплотную» не дотягивается
        val limit = 0.10 + wallThicknessM
        var dxMin = limit
        var dyMin = limit
        rooms.forEachIndexed { i, r ->
            if (i == activeRoom || r.spec.points.size < 3) return@forEachIndexed
            val bx0 = r.spec.points.minOf { it.x }
            val bx1 = r.spec.points.maxOf { it.x }
            val by0 = r.spec.points.minOf { it.y }
            val by1 = r.spec.points.maxOf { it.y }
            // между комнатами оставляем зазор ровно в толщину стены: тогда полосы стен
            // обеих комнат ложатся в него и выглядят одной общей стеной, а не налезают
            val t = wallThicknessM
            listOf(bx0 - t - ax1, bx1 + t - ax0, bx0 - ax0, bx1 - ax1).forEach { d ->
                if (abs(d) < dxMin) { dxMin = abs(d); bestX = d }
            }
            listOf(by0 - t - ay1, by1 + t - ay0, by0 - ay0, by1 - ay1).forEach { d ->
                if (abs(d) < dyMin) { dyMin = abs(d); bestY = d }
            }
        }
        return if (bestX != 0.0 || bestY != 0.0) Pt(bestX, bestY) else null
    }

    /** Пересекается ли контур-кандидат с другими комнатами квартиры. */
    private fun overlapsOthers(cand: List<Pt>): Boolean =
        rooms.withIndex().any { (i, r) -> i != activeRoom && polygonsOverlap(cand, r.spec.points) }

    /** Сводный итог по всем комнатам: штук к покупке и деньги при заданной цене. */
    /** Построчная сводка по всем комнатам квартиры: площадь, закупка, деньги. */
    fun apartmentStats(): List<RoomStat> {
        val app = getApplication<Application>()
        return rooms.mapIndexed { i, r ->
            val t = if (i == activeRoom) tile else r.tile
            val lay = if (i == activeRoom) layout else TilingEngine.build(r.spec, r.tile, r.pattern)
            val cnt = ceil(lay.totalCount * (1 + reservePct / 100.0)).toInt()
            val tileAreaM2 = t.widthMm * t.heightMm / 1_000_000.0
            val unit = if (prices.tilePc > 0) prices.tilePc else prices.tileM2 * tileAreaM2
            RoomStat(
                name = r.name.ifBlank { app.getString(R.string.room_n, i + 1) },
                areaM2 = lay.areaM2,
                buy = cnt,
                money = cnt * unit,
                tileLabel = t.widthMm.toInt().toString() + "×" + t.heightMm.toInt(),
            )
        }
    }

    fun apartmentPieces(): Pair<Int, Double> {
        val st = apartmentStats()
        return st.sumOf { it.buy } to st.sumOf { it.money }
    }

    /** Цены мастера: сохраняются вместе с проектом. */
    var prices by mutableStateOf(Prices())
        private set

    /** Фото пола для примерки (живёт в рамках сеанса). */
    var fitPhoto by mutableStateOf<ImageBitmap?>(null)
        private set

    /** Четыре угла пола на фото, в долях кадра: слева-сверху по часовой. */
    var fitQuad by mutableStateOf(
        listOf(Offset(0.16f, 0.34f), Offset(0.84f, 0.34f), Offset(0.97f, 0.93f), Offset(0.03f, 0.93f)),
    )
        private set

    /** Прозрачность наложенной раскладки. */
    var fitAlpha by mutableStateOf(0.8f)
        private set

    /** Логотип мастера для шапки PDF; хранится в filesDir/logo.png. */
    var masterLogo by mutableStateOf<ImageBitmap?>(null)
        private set

    /** Отделка по поверхностям: floor / wall-N / ceiling. */
    var finishes by mutableStateOf(mapOf("floor" to Finish.TILE, "ceiling" to Finish.PAINT))
        private set

    /** Проёмы (окна, двери) в координатах развёртки стены. */
    var openings by mutableStateOf(mapOf<String, List<Cutout>>())
        private set

    var activeSurface by mutableStateOf("floor")
        private set

    /** Открытая секция нижней панели; карточки статистики могут переключать её. */
    var panelSection by mutableStateOf(0)
        private set

    fun updatePanelSection(i: Int) { panelSection = i.coerceIn(0, 10) }

    /** Диалог точного ввода длин сторон у выбранной вершины. */
    var edgeDialog by mutableStateOf(false)
        private set

    fun updateEdgeDialog(v: Boolean) { edgeDialog = v }

    var filletDialog by mutableStateOf(false)
        private set

    fun updateFilletDialog(v: Boolean) { filletDialog = v }

    // ---------- черчение по точкам ----------

    var drawMode by mutableStateOf(false)
        private set

    var drawPts by mutableStateOf(listOf<Pt>())
        private set

    fun startDraw() {
        drawMode = true
        drawPts = emptyList()
        selection = null
        roomMode = true
    }

    fun cancelDraw() {
        drawMode = false
        drawPts = emptyList()
    }

    fun undoDrawPoint() {
        if (drawPts.isNotEmpty()) drawPts = drawPts.dropLast(1)
    }

    /** Добавить точку с прилипанием к горизонтали/вертикали от предыдущей. */
    fun addDrawPoint(w: Pt) {
        var x = round2(w.x)
        var y = round2(w.y)
        drawPts.lastOrNull()?.let { last ->
            if (abs(x - last.x) < 0.12) x = last.x
            if (abs(y - last.y) < 0.12) y = last.y
        }
        drawPts = drawPts + Pt(x, y)
    }

    fun drawOverlaps(): Boolean = drawPts.size >= 3 && overlapsOthers(drawPts)

    /** Замкнуть контур: он становится активной комнатой (вырезы очищаются). */
    fun finishDraw(): Boolean {
        if (drawPts.size < 3 || overlapsOthers(drawPts)) return false
        pushUndo()
        room = RoomSpec(drawPts, emptyList())
        drawMode = false
        drawPts = emptyList()
        selection = null
        reanchor()
        fit()
        return true
    }

    /** Скруглить выбранный угол дугой из 6 сегментов. */
    fun roundSelectedCorner(radius: Double) {
        val sel = selection as? Selection.Vertex ?: return
        val pts = room.points
        val n = pts.size
        if (n < 3 || sel.i !in pts.indices) return
        val c = pts[sel.i]
        val p = pts[(sel.i - 1 + n) % n]
        val q = pts[(sel.i + 1) % n]
        val l1 = sqrt((p.x - c.x) * (p.x - c.x) + (p.y - c.y) * (p.y - c.y))
        val l2 = sqrt((q.x - c.x) * (q.x - c.x) + (q.y - c.y) * (q.y - c.y))
        if (l1 < 1e-6 || l2 < 1e-6) return
        val u1x = (p.x - c.x) / l1
        val u1y = (p.y - c.y) / l1
        val u2x = (q.x - c.x) / l2
        val u2y = (q.y - c.y) / l2
        val cosT = (u1x * u2x + u1y * u2y).coerceIn(-1.0, 1.0)
        val theta = kotlin.math.acos(cosT)
        if (theta < 0.05 || theta > Math.PI - 0.05) return
        var r = radius.coerceIn(0.05, 10.0)
        var t = r / kotlin.math.tan(theta / 2)
        val tMax = minOf(l1, l2) * 0.9
        if (t > tMax) {
            t = tMax
            r = t * kotlin.math.tan(theta / 2)
        }
        val t1 = Pt(c.x + u1x * t, c.y + u1y * t)
        val t2 = Pt(c.x + u2x * t, c.y + u2y * t)
        val bl = sqrt((u1x + u2x) * (u1x + u2x) + (u1y + u2y) * (u1y + u2y))
        if (bl < 1e-6) return
        val o = Pt(
            c.x + (u1x + u2x) / bl * (r / kotlin.math.sin(theta / 2)),
            c.y + (u1y + u2y) / bl * (r / kotlin.math.sin(theta / 2)),
        )
        val a1 = kotlin.math.atan2(t1.y - o.y, t1.x - o.x)
        val a2 = kotlin.math.atan2(t2.y - o.y, t2.x - o.x)
        var sweep = a2 - a1
        while (sweep > Math.PI) sweep -= 2 * Math.PI
        while (sweep < -Math.PI) sweep += 2 * Math.PI
        val segs = 6
        val arc = (0..segs).map { k ->
            val ang = a1 + sweep * k / segs
            Pt(round2(o.x + r * kotlin.math.cos(ang)), round2(o.y + r * kotlin.math.sin(ang)))
        }
        val cand = pts.toMutableList()
        cand.removeAt(sel.i)
        cand.addAll(sel.i, arc)
        if (!overlapsOthers(cand)) {
            pushUndo()
            room = room.copy(points = cand)
            selection = null
        }
    }

    /** Ниша наружу по центру стены после выбранного угла (0.8 × 0.3 м). */
    fun addNicheAfterSelected(width: Double = 0.8, depth: Double = 0.3) {
        val sel = selection as? Selection.Vertex ?: return
        val pts = room.points
        val n = pts.size
        if (sel.i !in pts.indices) return
        val a = pts[sel.i]
        val b = pts[(sel.i + 1) % n]
        val ex = b.x - a.x
        val ey = b.y - a.y
        val len = sqrt(ex * ex + ey * ey)
        if (len < width + 0.2) return
        val ux = ex / len
        val uy = ey / len
        var nx = ey / len
        var ny = -ex / len
        val mid = Pt(a.x + ux * len / 2, a.y + uy * len / 2)
        if (pointInPolygon(Pt(mid.x + nx * 0.05, mid.y + ny * 0.05), pts)) {
            nx = -nx
            ny = -ny
        }
        val s0 = len / 2 - width / 2
        val s1 = len / 2 + width / 2
        fun at(sv: Double) = Pt(round2(a.x + ux * sv), round2(a.y + uy * sv))
        fun atOut(sv: Double) = Pt(
            round2(a.x + ux * sv + nx * depth),
            round2(a.y + uy * sv + ny * depth),
        )
        val cand = pts.toMutableList()
        cand.addAll(sel.i + 1, listOf(at(s0), atOut(s0), atOut(s1), at(s1)))
        if (!overlapsOthers(cand)) {
            pushUndo()
            room = room.copy(points = cand)
        }
    }

    /** Избранные размеры плитки: (ширина, длина, шов) в мм. */
    var favTiles by mutableStateOf(listOf<Triple<Double, Double, Double>>())
        private set

    private fun favPrefs() =
        getApplication<Application>().getSharedPreferences("ba_fav", Context.MODE_PRIVATE)

    private fun persistFavs() {
        favPrefs().edit().putString(
            "tiles",
            favTiles.joinToString(";") { it.first.toString() + ":" + it.second + ":" + it.third },
        ).apply()
    }

    fun toggleFavTile() {
        val cur = Triple(tile.widthMm, tile.heightMm, tile.groutMm)
        favTiles = if (favTiles.contains(cur)) favTiles - cur else (favTiles + cur).takeLast(8)
        persistFavs()
    }

    fun applyFavTile(t: Triple<Double, Double, Double>) {
        pushUndo()
        tile = TileSpec(t.first, t.second, t.third)
        reanchor()
    }

    /** Точная длина сторон: соседние углы сдвигаются вдоль текущих направлений. */
    fun applyEdgeLengths(prevLen: Double, nextLen: Double) {
        val sel = selection as? Selection.Vertex ?: return
        val pts = room.points.toMutableList()
        val n = pts.size
        if (n < 3 || sel.i !in pts.indices) return
        val cur = pts[sel.i]
        fun moved(fromIdx: Int, len: Double): Pt {
            val p = pts[fromIdx]
            val dx = p.x - cur.x
            val dy = p.y - cur.y
            val len0 = sqrt(dx * dx + dy * dy)
            if (len0 < 1e-6) return p
            val k = len / len0
            return Pt(round2(cur.x + dx * k), round2(cur.y + dy * k))
        }
        val cand = pts.toMutableList()
        if (prevLen > 0.05) cand[(sel.i - 1 + n) % n] = moved((sel.i - 1 + n) % n, prevLen)
        if (nextLen > 0.05) cand[(sel.i + 1) % n] = moved((sel.i + 1) % n, nextLen)
        if (!overlapsOthers(cand)) {
            pushUndo()
            room = room.copy(points = cand)
        }
    }

    /** Плотность экрана: пороги захвата пальцем задаются в dp и умножаются на неё. */
    private var uiScale = 1f

    fun updateUiScale(v: Float) { uiScale = v.coerceIn(0.5f, 5f) }

    var selection by mutableStateOf<Selection?>(null)
        private set

    var view by mutableStateOf(ViewTransform())
        private set

    var hintVisible by mutableStateOf(true)
        private set

    var projectName by mutableStateOf("")

    var projects by mutableStateOf<List<ProjectMeta>>(emptyList())
        private set

    var suggestions by mutableStateOf<List<LayoutSuggester.Suggestion>?>(null)
        private set

    /** Размер холста в пикселях; обычное поле, не состояние (нужно только для fit/жестов). */
    var canvasSize: Size = Size.Zero
    private var lastFitSize: Size = Size.Zero

    // ---------- производные ----------

    // ---------- зоны: участки со своей плиткой внутри комнаты ----------

    var zones by mutableStateOf(listOf<ZoneDto>())
        private set

    /** Выбранная зона: пока она выбрана, настройки плитки применяются к ней. */
    var activeZone by mutableStateOf(-1)
        private set

    fun updateActiveZone(i: Int) { activeZone = if (i in zones.indices) i else -1 }

    /** Резервный способ добавить зону; основной — кисть размера. */
    fun addZone() {
        pushUndo()
        val c = roomCenter()
        val z = ZoneDto(
            x = round2(c.x - 0.6),
            y = round2(c.y - 0.6),
            w = 1.2,
            h = 1.2,
            tile = TileSpec(300.0, 300.0, tile.groutMm),
            pattern = PatternSpec(),
        )
        zones = zones + z
        activeZone = zones.lastIndex
        selection = null
    }

    fun deleteActiveZone() {
        if (activeZone !in zones.indices) return
        pushUndo()
        val list = zones.toMutableList()
        list.removeAt(activeZone)
        zones = list
        activeZone = -1
    }

    private fun updateZone(i: Int, f: (ZoneDto) -> ZoneDto) {
        if (i !in zones.indices) return
        val list = zones.toMutableList()
        list[i] = f(list[i])
        zones = list
    }

    /** Плитка и узор, которые сейчас редактируются: комнаты или выбранной зоны. */
    val uiTile: TileSpec get() = zones.getOrNull(activeZone)?.tile ?: tile
    val uiPattern: PatternSpec get() = zones.getOrNull(activeZone)?.pattern ?: pattern
    val uiColor: Color get() =
        zones.getOrNull(activeZone)?.let { if (it.colorArgb != -1) Color(it.colorArgb) else tileColor } ?: tileColor
    val uiVariation: Boolean get() = zones.getOrNull(activeZone)?.variation ?: variation

    /** Базовая раскладка: зоны вычтены из неё как отверстия, поэтому стык режется честно. */
    val layout: LayoutResult by derivedStateOf {
        val holes = room.cutouts + zones.map { Cutout(it.x, it.y, it.w, it.h) }
        TilingEngine.build(room.copy(cutouts = holes), tile, pattern)
    }

    /** Раскладки зон: контур зоны = комната ∩ прямоугольник зоны. */
    val zoneLayouts: List<Pair<ZoneDto, LayoutResult>> by derivedStateOf {
        zones.mapNotNull { z ->
            val poly = clipPolygonByRect(room.points, z.x, z.y, z.x + z.w, z.y + z.h)
            if (poly.size < 3) {
                null
            } else {
                val inner = room.cutouts.filter {
                    it.x < z.x + z.w && it.x + it.w > z.x && it.y < z.y + z.h && it.y + it.h > z.y
                }
                z to TilingEngine.build(RoomSpec(poly, inner), z.tile, z.pattern)
            }
        }
    }

    /** Сколько плитки покупать по каждому формату: «600×600» → штук с запасом. */
    fun countsByFormat(): List<Pair<String, Int>> {
        val map = LinkedHashMap<String, Int>()
        fun add(t: TileSpec, count: Int) {
            val key = t.widthMm.toInt().toString() + "×" + t.heightMm.toInt()
            map[key] = (map[key] ?: 0) + count
        }
        add(tile, layout.totalCount)
        zoneLayouts.forEach { (z, l) -> add(z.tile, l.totalCount) }
        return map.map { (k, v) -> k to ceil(v * (1 + reservePct / 100.0)).toInt() }
    }

    /** Индексы декоративных плиток текущей раскладки. */
    // ---------- подложка: фото чертежа под рабочей областью ----------

    /** Фото плана (живёт в рамках сеанса — картинку в проект не пишем). */
    var planImage by mutableStateOf<ImageBitmap?>(null)
        private set

    /** Мировые координаты левого верхнего угла подложки. */
    var planOrigin by mutableStateOf(Pt(0.0, 0.0))
        private set

    /** Масштаб подложки: метров на пиксель картинки. */
    var planMPerPx by mutableStateOf(0.01)
        private set

    var planAlpha by mutableStateOf(0.45f)
        private set

    /** Режим перетаскивания подложки. */
    var planMove by mutableStateOf(false)
        private set

    /** Размеры, прочитанные с чертежа: значение в метрах + точка в МИРОВЫХ координатах. */
    var ocrNumbers by mutableStateOf(listOf<Triple<Double, Pt, Boolean>>())
        private set

    var ocrBusy by mutableStateOf(false)
        private set

    /** Читает числа на подложке. Печатные чертежи — уверенно, рукописные — как получится. */
    fun runPlanOcr() {
        val src = planImage ?: return
        if (ocrBusy) return
        ocrBusy = true
        viewModelScope.launch {
            val prepared = withContext(Dispatchers.Default) {
                val full = src.asAndroidBitmap()
                val maxSide = 1600
                val k = minOf(1.0, maxSide.toDouble() / maxOf(full.width, full.height))
                val bmp = if (k < 1.0) {
                    android.graphics.Bitmap.createScaledBitmap(
                        full,
                        (full.width * k).toInt().coerceAtLeast(8),
                        (full.height * k).toInt().coerceAtLeast(8),
                        true,
                    )
                } else {
                    full
                }
                bmp to k
            }
            runCatching {
                PlanOcr.read(prepared.first) { list ->
                    val k = prepared.second
                    ocrNumbers = list.map {
                        Triple(
                            it.meters,
                            Pt(
                                planOrigin.x + it.cx / k * planMPerPx,
                                planOrigin.y + it.cy / k * planMPerPx,
                            ),
                            it.horizontal,
                        )
                    }
                    ocrBusy = false
                    if (ocrNumbers.isEmpty()) toast(R.string.ocr_none)
                }
            }.onFailure {
                ocrBusy = false
                toast(R.string.ocr_none)
            }
        }
    }

    fun clearOcr() { ocrNumbers = emptyList() }

    /** Числа с чертежа рядом с точкой — для подсказок в диалогах длин. */
    fun ocrNear(p: Pt, limit: Int = 6): List<Double> =
        ocrNumbers
            .sortedBy { (it.second.x - p.x) * (it.second.x - p.x) + (it.second.y - p.y) * (it.second.y - p.y) }
            .take(limit)
            .map { it.first }

    /** Режим автообводки: касание внутри помещения на фото строит контур. */
    var traceMode by mutableStateOf(false)
        private set

    fun toggleTraceMode() {
        traceMode = !traceMode
        if (traceMode) {
            calibMode = false
            planMove = false
        }
    }

    /**
     * Обводит помещение по фото: точка касания переводится в пиксели подложки,
     * PlanTracer возвращает контур, он переводится обратно в метры.
     */
    fun autoTrace(world: Pt) {
        val src = planImage ?: return
        viewModelScope.launch {
            val res = withContext(Dispatchers.Default) {
                val full = src.asAndroidBitmap()
                val maxSide = 700
                val k = minOf(1.0, maxSide.toDouble() / maxOf(full.width, full.height))
                val bw = (full.width * k).toInt().coerceAtLeast(8)
                val bh = (full.height * k).toInt().coerceAtLeast(8)
                val small = if (k < 1.0) {
                    android.graphics.Bitmap.createScaledBitmap(full, bw, bh, true)
                } else {
                    full
                }
                val px = IntArray(bw * bh)
                small.getPixels(px, 0, bw, 0, 0, bw, bh)
                // мир → пиксели уменьшенной картинки
                val sxp = ((world.x - planOrigin.x) / planMPerPx * k).toInt()
                val syp = ((world.y - planOrigin.y) / planMPerPx * k).toInt()
                PlanTracer.trace(px, bw, bh, sxp, syp) to k
            }
            val traced = res.first
            val k = res.second
            if (traced == null || traced.points.size < 3) {
                traceMode = false
                toast(R.string.plan_trace_fail)
                return@launch
            }
            val pts = traced.points.map {
                Pt(
                    round2(planOrigin.x + it[0] / k * planMPerPx),
                    round2(planOrigin.y + it[1] / k * planMPerPx),
                )
            }
            if (overlapsOthers(pts)) {
                traceMode = false
                toast(R.string.plan_trace_fail)
                return@launch
            }
            pushUndo()
            room = RoomSpec(pts, emptyList())
            selection = null
            suggestions = null
            traceMode = false
            reanchor()
            fit()
        }
    }

    /** Режим калибровки: два касания задают отрезок известной длины. */
    var calibMode by mutableStateOf(false)
        private set

    var calibA by mutableStateOf<Pt?>(null)
        private set

    var calibB by mutableStateOf<Pt?>(null)
        private set

    var calibDialog by mutableStateOf(false)
        private set

    fun loadPlanImage(context: Context, uri: Uri) {
        viewModelScope.launch {
            val bmp = withContext(Dispatchers.IO) { decodeBitmap(context, uri) } ?: return@launch
            planImage = bmp
            // по умолчанию подложка шириной ~8 м, вписана рядом с началом координат
            planMPerPx = 8.0 / bmp.width.coerceAtLeast(1)
            planOrigin = Pt(0.0, 0.0)
            planMove = false
            calibMode = false
            calibA = null
            calibB = null
        }
    }

    fun clearPlanImage() {
        planImage = null
        ocrNumbers = emptyList()
        planMove = false
        calibMode = false
        calibA = null
        calibB = null
    }

    fun updatePlanAlpha(a: Float) { planAlpha = a.coerceIn(0.15f, 1f) }

    fun togglePlanMove() {
        planMove = !planMove
        if (planMove) calibMode = false
    }

    fun startCalibration() {
        calibMode = true
        planMove = false
        calibA = null
        calibB = null
    }

    fun addCalibPoint(p: Pt) {
        if (calibA == null) {
            calibA = p
        } else if (calibB == null) {
            calibB = p
            calibDialog = true
        }
    }

    fun updateCalibDialog(v: Boolean) {
        calibDialog = v
        if (!v) {
            calibMode = false
            calibA = null
            calibB = null
        }
    }

    /** Приводит масштаб подложки так, чтобы отрезок калибровки стал заданной длины. */
    fun applyCalibration(realM: Double) {
        val a = calibA
        val b = calibB
        if (a == null || b == null || realM <= 0.01) return
        val d0 = sqrt((a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y))
        if (d0 < 1e-6) return
        val k = realM / d0
        planMPerPx *= k
        // масштабируем вокруг первой точки, чтобы она осталась на месте
        planOrigin = Pt(a.x + (planOrigin.x - a.x) * k, a.y + (planOrigin.y - a.y) * k)
        calibMode = false
        calibA = null
        calibB = null
        calibDialog = false
    }

    /** Толщина стен: показывается на плане и даёт стенам объём в 3D. */
    var wallThicknessM by mutableStateOf(0.10)
        private set

    fun updateWallThickness(m: Double) { wallThicknessM = m.coerceIn(0.02, 0.6) }

    // ---------- панно: одна картинка на несколько плиток ----------

    var panelOn by mutableStateOf(false)
        private set

    /** Левый верхний угол панно в координатах раскладки — панно едет вместе с узором. */
    var panelRX by mutableStateOf(0.0)
        private set

    var panelRY by mutableStateOf(0.0)
        private set

    /** Ставит панно так, чтобы выбранная плитка стала его левым верхним углом. */
    fun placePanelAtSelected() {
        val sel = selection as? Selection.Tile ?: return
        val t = layout.tiles.getOrNull(sel.i) ?: return
        pushUndo()
        panelRX = t.rect.x
        panelRY = t.rect.y
        panelOn = true
    }

    fun clearPanel() {
        pushUndo()
        panelOn = false
    }

    /** Клетка панно для плитки: (столбец, строка) или null, если плитка вне панно. */
    fun panelCell(t: PlacedTile): Pair<Int, Int>? {
        if (!panelOn) return null
        val stepW = (tile.widthMm + tile.groutMm) / 1000.0
        val stepH = (tile.heightMm + tile.groutMm) / 1000.0
        if (stepW <= 1e-6 || stepH <= 1e-6) return null
        val col = ((t.rect.x - panelRX) / stepW).roundToInt()
        val row = ((t.rect.y - panelRY) / stepH).roundToInt()
        if (col < 0 || row < 0 || col >= decor.panelCols || row >= decor.panelRows) return null
        // плитка должна стоять в узле решётки, а не просто рядом
        if (abs(t.rect.x - (panelRX + col * stepW)) > stepW * 0.3) return null
        if (abs(t.rect.y - (panelRY + row * stepH)) > stepH * 0.3) return null
        return col to row
    }

    /** Слои зон для 3D, AR и PDF. */
    fun zoneLayers(): List<ExtraLayer> = zoneLayouts.map { (z, l) ->
        ExtraLayer(
            tiles = l.tiles,
            colorArgb = if (z.colorArgb != -1) z.colorArgb else Color(0xFFE8DFD2).toArgb(),
            variation = z.variation,
        )
    }

    /** Описание панно для отрисовки в 3D, AR и PDF. */
    fun panelInfo(): PanelInfo? =
        if (panelOn && decorImage != null) {
            PanelInfo(decor.panelCols, decor.panelRows) { t -> panelCell(t) }
        } else {
            null
        }

    /** Цвет отдельных плиток: ключ «см:см» в координатах раскладки — едет вместе с узором. */
    var tileColors by mutableStateOf(mapOf<String, Int>())
        private set

    /** Кисть размера: проводишь по полу — участок становится зоной с этим форматом. */
    var formatBrush by mutableStateOf(false)
        private set

    var brushTile by mutableStateOf(TileSpec(300.0, 300.0, 3.0))
        private set

    private var brushMinX = 0.0
    private var brushMinY = 0.0
    private var brushMaxX = 0.0
    private var brushMaxY = 0.0
    private var brushHit = false

    fun toggleFormatBrush() {
        formatBrush = !formatBrush
        if (formatBrush) paintMode = false
    }

    fun updateBrushTile(t: TileSpec) {
        brushTile = t
        formatBrush = true
        paintMode = false
    }

    private fun brushTouch(w: Pt) {
        val t = layout.tiles.firstOrNull { pointInPolygon(w, it.corners) } ?: return
        val xs = t.corners.map { it.x }
        val ys = t.corners.map { it.y }
        if (!brushHit) {
            brushHit = true
            brushMinX = xs.min()
            brushMaxX = xs.max()
            brushMinY = ys.min()
            brushMaxY = ys.max()
        } else {
            brushMinX = minOf(brushMinX, xs.min())
            brushMaxX = maxOf(brushMaxX, xs.max())
            brushMinY = minOf(brushMinY, ys.min())
            brushMaxY = maxOf(brushMaxY, ys.max())
        }
    }

    /** Заканчивает мазок: из охваченных плиток получается зона со своим форматом. */
    private fun brushFinish() {
        if (!brushHit) return
        brushHit = false
        val w = round2(brushMaxX - brushMinX)
        val h = round2(brushMaxY - brushMinY)
        if (w < 0.05 || h < 0.05) return
        pushOnce()
        zones = zones + ZoneDto(
            x = round2(brushMinX),
            y = round2(brushMinY),
            w = w,
            h = h,
            tile = brushTile,
            pattern = PatternSpec(type = pattern.type),
        )
        activeZone = zones.lastIndex
        formatBrush = false
    }

    /** Режим кисти: проводишь пальцем — плитки красятся выбранным цветом. */
    var paintMode by mutableStateOf(false)
        private set

    var paintColor by mutableStateOf(Color(0xFF8FB8E8).toArgb())
        private set

    fun togglePaintMode() { paintMode = !paintMode }

    fun updatePaintColor(c: Int) {
        paintColor = c
        paintMode = true
    }

    /** Красит плитку под пальцем; повторное касание уже покрашенной снимает цвет. */
    fun paintTileAt(w: Pt, erase: Boolean = false) {
        val idx = layout.tiles.indexOfFirst { pointInPolygon(w, it.corners) }
        if (idx < 0) return
        val key = tileKey(layout.tiles[idx])
        val m = tileColors.toMutableMap()
        if (erase) {
            m.remove(key)
        } else if (m[key] == paintColor) {
            m.remove(key)
        } else {
            m[key] = paintColor
        }
        tileColors = m
    }

    fun colorOfTile(t: PlacedTile): Int? = tileColors[tileKey(t)]

    fun clearTileColors() {
        pushUndo()
        tileColors = emptyMap()
    }

    /** Ручной декор: ключ «см:см» начала плитки → true (декор) / false (снять авто). */
    var decorOverrides by mutableStateOf(mapOf<String, Boolean>())
        private set

    private fun tileKey(t: PlacedTile): String =
        (t.rect.x * 100).roundToInt().toString() + ":" + (t.rect.y * 100).roundToInt()

    fun toggleTileDecor() {
        val sel = selection as? Selection.Tile ?: return
        val t = layout.tiles.getOrNull(sel.i) ?: return
        pushUndo()
        val m = decorOverrides.toMutableMap()
        m[tileKey(t)] = sel.i !in decorIdx
        decorOverrides = m
    }

    /** Точный размер полезного куска каждой подрезанной плитки, см (как в движке). */
    val cutPieceOf: Map<Int, Pair<Double, Double>> by derivedStateOf {
        val res = mutableMapOf<Int, Pair<Double, Double>>()
        val poly = room.points
        layout.tiles.forEachIndexed { i, t ->
            if (t.cls != TileClass.CUT) return@forEachIndexed
            val q = t.corners
            val piece = clipPolygonByQuad(poly, q)
            if (piece.size < 3) return@forEachIndexed
            // локальные оси плитки
            val ux = q[1].x - q[0].x
            val uy = q[1].y - q[0].y
            val vx = q[3].x - q[0].x
            val vy = q[3].y - q[0].y
            val ulen = sqrt(ux * ux + uy * uy)
            val vlen = sqrt(vx * vx + vy * vy)
            if (ulen < 1e-9 || vlen < 1e-9) return@forEachIndexed
            var lx1 = Double.MAX_VALUE
            var lx2 = -Double.MAX_VALUE
            var ly1 = Double.MAX_VALUE
            var ly2 = -Double.MAX_VALUE
            for (p in piece) {
                val dx = p.x - q[0].x
                val dy = p.y - q[0].y
                val lx = (dx * ux + dy * uy) / ulen
                val ly = (dx * vx + dy * vy) / vlen
                if (lx < lx1) lx1 = lx
                if (lx > lx2) lx2 = lx
                if (ly < ly1) ly1 = ly
                if (ly > ly2) ly2 = ly
            }
            val pw = max(0.0, min(ulen, lx2) - max(0.0, lx1))
            val ph = max(0.0, min(vlen, ly2) - max(0.0, ly1))
            // округление до полусантиметра — ровно как в списке обрезков
            val aCm = Math.round(max(pw, ph) * 200).toDouble() / 2.0
            val bCm = Math.round(min(pw, ph) * 200).toDouble() / 2.0
            if (aCm >= 1.0) res[i] = aCm to bCm
        }
        res
    }

    /** Подсветка плиток, чей остаток совпадает с выбранной строкой обрезков. */
    var highlightCut by mutableStateOf<Pair<Double, Double>?>(null)
        private set

    fun clearHighlightCut() { highlightCut = null }

    fun toggleHighlightCut(a: Double, b: Double) {
        val v = a to b
        highlightCut = if (highlightCut == v) null else v
    }

    val decorIdx: Set<Int> by derivedStateOf {
        val auto = DecorPlanner.select(layout, tile, decor, roomCenter())
        if (decorOverrides.isEmpty()) {
            auto
        } else {
            layout.tiles.indices.filter { i ->
                when (decorOverrides[tileKey(layout.tiles[i])]) {
                    true -> true
                    false -> false
                    null -> i in auto
                }
            }.toSet()
        }
    }

    /** Перекрытие декора мебелью и плитки под ней. */
    val coverage: CoverageReport by derivedStateOf {
        CoverageAnalyzer.analyze(layout, tile, decorIdx, decor.art, furniture)
    }

    /** Подрезка по каждой стене + предупреждения. */
    val cutReport: CutReport by derivedStateOf { CutAnalyzer.analyze(room, tile, layout) }

    fun roomCenter(): Pt {
        val pts = room.points
        if (pts.isEmpty()) return Pt(0.0, 0.0)
        return Pt(
            (pts.minOf { it.x } + pts.maxOf { it.x }) / 2,
            (pts.minOf { it.y } + pts.maxOf { it.y }) / 2,
        )
    }

    val buyCount: Int get() = ceil(layout.totalCount * (1 + reservePct / 100.0)).toInt()

    val buyM2: Double get() = buyCount * tile.widthMm * tile.heightMm / 1e6

    // ---------- история изменений ----------

    private data class Snap(
        val room: RoomSpec,
        val tile: TileSpec,
        val pattern: PatternSpec,
        val tileColor: Color,
        val variation: Boolean,
        val reservePct: Int,
        val decor: DecorSpec,
        val anchor: AnchorMode,
        val furniture: List<Furniture>,
        val finishes: Map<String, Finish>,
        val openings: Map<String, List<Cutout>>,
        val wallHeightM: Double,
        val wallThicknessM: Double,
        val rooms: List<RoomDto>,
        val activeRoom: Int,
        val decorOverrides: Map<String, Boolean>,
        val panelOn: Boolean,
        val panelRX: Double,
        val panelRY: Double,
        val zones: List<ZoneDto>,
        val tileColors: Map<String, Int>,
    )

    private val undoStack = ArrayDeque<Snap>()
    private val redoStack = ArrayDeque<Snap>()

    var canUndo by mutableStateOf(false)
        private set

    var canRedo by mutableStateOf(false)
        private set

    private fun snap() = Snap(
        room, tile, pattern, tileColor, variation, reservePct,
        decor, anchor, furniture, finishes, openings, wallHeightM, wallThicknessM,
        rooms, activeRoom, decorOverrides, panelOn, panelRX, panelRY, zones, tileColors,
    )

    /** Запомнить состояние перед изменением. */
    fun pushUndo() {
        undoStack.addLast(snap())
        if (undoStack.size > 40) undoStack.removeFirst()
        redoStack.clear()
        canUndo = true
        canRedo = false
    }

    private fun restore(s: Snap) {
        room = s.room
        tile = s.tile
        pattern = s.pattern
        tileColor = s.tileColor
        variation = s.variation
        reservePct = s.reservePct
        decor = s.decor
        anchor = s.anchor
        furniture = s.furniture
        finishes = s.finishes
        openings = s.openings
        wallHeightM = s.wallHeightM
        wallThicknessM = s.wallThicknessM
        rooms = s.rooms
        activeRoom = s.activeRoom
        decorOverrides = s.decorOverrides
        panelOn = s.panelOn
        panelRX = s.panelRX
        panelRY = s.panelRY
        zones = s.zones
        tileColors = s.tileColors
        selection = null
        suggestions = null
    }

    fun undo() {
        val s = undoStack.removeLastOrNull() ?: return
        redoStack.addLast(snap())
        restore(s)
        canUndo = undoStack.isNotEmpty()
        canRedo = true
    }

    fun redo() {
        val s = redoStack.removeLastOrNull() ?: return
        undoStack.addLast(snap())
        restore(s)
        canRedo = redoStack.isNotEmpty()
        canUndo = true
    }

    // ---------- преобразования координат ----------

    fun toWorld(o: Offset): Pt = Pt(
        ((o.x - view.offset.x) / view.scale).toDouble(),
        ((o.y - view.offset.y) / view.scale).toDouble(),
    )

    fun toScreen(p: Pt): Offset = Offset(
        (p.x * view.scale + view.offset.x).toFloat(),
        (p.y * view.scale + view.offset.y).toFloat(),
    )

    private var didInitialFit = false

    fun maybeInitialFit() {
        // смена раскладки (телефон ↔ планшет) сильно меняет холст — вписываем заново
        if (didInitialFit && canvasSize.width > 0f && lastFitSize.width > 0f &&
            (kotlin.math.abs(canvasSize.width - lastFitSize.width) > lastFitSize.width * 0.25f ||
                kotlin.math.abs(canvasSize.height - lastFitSize.height) > lastFitSize.height * 0.25f)
        ) {
            lastFitSize = canvasSize
            fit()
        }
        if (!didInitialFit && canvasSize.width > 0f && canvasSize.height > 0f) {
            didInitialFit = true
            fit()
        }
    }

    /** Вписать план комнаты в холст. */
    fun fit() {
        if (canvasSize.width <= 0f || canvasSize.height <= 0f || room.points.isEmpty()) return
        lastFitSize = canvasSize
        val allPts = room.points +
            rooms.filterIndexed { i, _ -> i != activeRoom }.flatMap { it.spec.points }
        val minx = allPts.minOf { it.x }
        val maxx = allPts.maxOf { it.x }
        val miny = allPts.minOf { it.y }
        val maxy = allPts.maxOf { it.y }
        val bw = max(0.5, maxx - minx)
        val bh = max(0.5, maxy - miny)
        val s = max(
            12f,
            min(
                ((canvasSize.width - 76f) / bw).toFloat(),
                ((canvasSize.height - 96f) / bh).toFloat(),
            ),
        )
        val ox = canvasSize.width / 2f - ((minx + maxx) / 2 * s).toFloat()
        val oy = canvasSize.height / 2f - ((miny + maxy) / 2 * s).toFloat()
        view = ViewTransform(s, Offset(ox, oy))
    }

    // ---------- жесты ----------

    private enum class Drag { NONE, PAN, PATTERN, VERTEX, CUT_MOVE, CUT_RESIZE, FURN_MOVE, FURN_RESIZE, ROOM_MOVE, PLAN_MOVE, ZONE_MOVE, ZONE_RESIZE, PAINT, FORMAT }

    private var drag = Drag.NONE
    private var dragIndex = -1
    private var grabDx = 0.0
    private var grabDy = 0.0
    private var movedFurn: List<Int> = emptyList()
    private var pendingSwitch = -1
    private var panMoved = false
    private var tappedTile = -1
    private var patternMoved = false

    private var editSnapPushed = false

    /** Снимок для отмены — один раз на жест, сколько бы веток ни сработало. */
    private fun pushOnce() {
        if (!editSnapPushed) {
            pushUndo()
            editSnapPushed = true
        }
    }

    fun gestureDown(pos: Offset) {
        hintVisible = false
        drag = Drag.NONE
        dragIndex = -1
        editSnapPushed = false
        val w = toWorld(pos)
        if (formatBrush && !roomMode) {
            brushHit = false
            brushTouch(Pt(w.x, w.y))
            drag = Drag.FORMAT
            return
        }
        if (paintMode && !roomMode) {
            pushOnce()
            paintTileAt(Pt(w.x, w.y))
            drag = Drag.PAINT
            return
        }
        if (traceMode && planImage != null) {
            autoTrace(Pt(w.x, w.y))
            drag = Drag.NONE
            return
        }
        if (calibMode && planImage != null) {
            addCalibPoint(Pt(w.x, w.y))
            drag = Drag.NONE
            return
        }
        if (planMove && planImage != null) {
            drag = Drag.PLAN_MOVE
            grabDx = w.x - planOrigin.x
            grabDy = w.y - planOrigin.y
            return
        }
        if (drawMode) {
            if (drawPts.size >= 3 &&
                (toScreen(drawPts.first()) - pos).getDistance() < 26f * uiScale
            ) {
                finishDraw()
            } else {
                addDrawPoint(Pt(w.x, w.y))
            }
            drag = Drag.NONE
            return
        }
        // касание по ДРУГОЙ комнате: сразу делаем её активной и тащим — одним жестом,
        // и ручки активной комнаты при этом не перехватывают касание (иначе ставилась точка)
        pendingSwitch = -1
        panMoved = false
        // вершину активной комнаты на общей стене не отдаём соседке
        val nearActiveVertex = room.points.any { (toScreen(it) - pos).getDistance() < 26f * uiScale }
        if (!nearActiveVertex && !pointInPolygon(w, room.points)) {
            var other = -1
            rooms.forEachIndexed { i, r ->
                if (other < 0 && i != activeRoom && pointInPolygon(w, r.spec.points)) other = i
            }
            if (other >= 0) {
                switchRoom(other)
                if (roomMode) {
                    drag = Drag.ROOM_MOVE
                    grabDx = w.x
                    grabDy = w.y
                    movedFurn = furniture.indices.filter { idx ->
                        val f = furniture[idx]
                        pointInPolygon(Pt(f.x + f.w / 2, f.y + f.h / 2), room.points)
                    }
                    selection = null
                } else {
                    drag = Drag.PAN
                }
                return
            }
        }
        if (!roomMode) {
            patternMoved = false
            tappedTile = -1
            if (pointInPolygon(w, room.points)) {
                pushOnce()
                drag = Drag.PATTERN
                tappedTile = layout.tiles.indexOfFirst { pointInPolygon(w, it.corners) }
            } else {
                drag = Drag.PAN
            }
            return
        }

        // 1. вершина
        room.points.forEachIndexed { i, p ->
            if (drag == Drag.NONE && (toScreen(p) - pos).getDistance() < 26f * uiScale) {
                pushOnce()
                drag = Drag.VERTEX
                dragIndex = i
                selection = Selection.Vertex(i)
            }
        }
        if (drag != Drag.NONE) return

        // 2. «+» на середине ребра (только если палец не над другой комнатой)
        val overOther = rooms.withIndex().any { (i, r) ->
            i != activeRoom && r.spec.points.size >= 3 && pointInPolygon(w, r.spec.points)
        }
        if (overOther) {
            drag = Drag.PAN
            selection = null
            return
        }
        // 2. «+» на середине ребра
        val pts = room.points
        for (i in pts.indices) {
            val a = pts[i]
            val b = pts[(i + 1) % pts.size]
            val sa = toScreen(a)
            val sb = toScreen(b)
            if ((sb - sa).getDistance() < 56f * uiScale) continue
            val mid = Offset((sa.x + sb.x) / 2f, (sa.y + sb.y) / 2f)
            if ((mid - pos).getDistance() < 22f * uiScale) {
                val np = Pt((a.x + b.x) / 2, (a.y + b.y) / 2)
                val list = pts.toMutableList()
                list.add(i + 1, np)
                room = room.copy(points = list)
                drag = Drag.VERTEX
                dragIndex = i + 1
                selection = Selection.Vertex(i + 1)
                return
            }
        }

        // 3. ручка выреза (правый нижний угол)
        room.cutouts.forEachIndexed { i, c ->
            if (drag == Drag.NONE &&
                (toScreen(Pt(c.x + c.w, c.y + c.h)) - pos).getDistance() < 26f * uiScale
            ) {
                pushOnce()
                pushOnce()
            drag = Drag.CUT_RESIZE
                dragIndex = i
                selection = Selection.Cut(i)
            }
        }
        if (drag != Drag.NONE) return

        // 4. тело выреза
        room.cutouts.forEachIndexed { i, c ->
            if (drag == Drag.NONE &&
                w.x > c.x && w.x < c.x + c.w && w.y > c.y && w.y < c.y + c.h
            ) {
                pushOnce()
                pushOnce()
            drag = Drag.CUT_MOVE
                dragIndex = i
                grabDx = w.x - c.x
                grabDy = w.y - c.y
                selection = Selection.Cut(i)
            }
        }
        if (drag != Drag.NONE) return

        // 5. мебель: угловая ручка и перенос
        furniture.forEachIndexed { i, f ->
            if (drag == Drag.NONE &&
                (toScreen(Pt(f.x + f.w, f.y + f.h)) - pos).getDistance() < 26f * uiScale
            ) {
                pushOnce()
                pushOnce()
            drag = Drag.FURN_RESIZE
                dragIndex = i
                selection = Selection.Furn(i)
            }
        }
        if (drag != Drag.NONE) return
        furniture.forEachIndexed { i, f ->
            if (drag == Drag.NONE && w.x > f.x && w.x < f.x + f.w && w.y > f.y && w.y < f.y + f.h) {
                pushOnce()
                pushOnce()
            drag = Drag.FURN_MOVE
                dragIndex = i
                grabDx = w.x - f.x
                grabDy = w.y - f.y
                selection = Selection.Furn(i)
            }
        }
        if (drag != Drag.NONE) return

        // 5b2. зоны: угол — размер, внутри — перенос
        zones.forEachIndexed { i, z ->
            if (drag != Drag.NONE) return@forEachIndexed
            val corner = toScreen(Pt(z.x + z.w, z.y + z.h))
            if ((corner - pos).getDistance() < 26f * uiScale) {
                pushOnce()
                pushOnce()
            drag = Drag.ZONE_RESIZE
                dragIndex = i
                activeZone = i
                selection = Selection.Zone(i)
                return
            }
        }
        zones.forEachIndexed { i, z ->
            if (drag != Drag.NONE) return@forEachIndexed
            if (w.x > z.x && w.x < z.x + z.w && w.y > z.y && w.y < z.y + z.h) {
                pushOnce()
                pushOnce()
            drag = Drag.ZONE_MOVE
                dragIndex = i
                activeZone = i
                selection = Selection.Zone(i)
                grabDx = w.x - z.x
                grabDy = w.y - z.y
                return
            }
        }

        // 5c. перенос всей комнаты: захват изнутри активного контура
        if (pointInPolygon(w, room.points)) {
            pushOnce()
            drag = Drag.ROOM_MOVE
            grabDx = w.x
            grabDy = w.y
            movedFurn = furniture.indices.filter { idx ->
                val f = furniture[idx]
                pointInPolygon(Pt(f.x + f.w / 2, f.y + f.h / 2), room.points)
            }
            selection = null
            return
        }

        // 6. панорамирование
        drag = Drag.PAN
        selection = null
    }

    private var gestureSnapped = false

    fun gestureMove(pos: Offset, prev: Offset) {
        if (!gestureSnapped && drag != Drag.NONE && drag != Drag.PAN) {
            gestureSnapped = true
            pushUndo()
        }
        val d = pos - prev
        when (drag) {
            Drag.PAN -> {
                if (d.getDistance() > 3f) panMoved = true
                view = view.copy(offset = view.offset + d)
            }

            Drag.PATTERN -> {
                if (d.getDistance() > 3f) patternMoved = true
                anchor = AnchorMode.FREE
                pattern = pattern.copy(
                offsetX = pattern.offsetX + d.x / view.scale,
                    offsetY = pattern.offsetY + d.y / view.scale,
                )
            }

            Drag.VERTEX -> {
                val pts = room.points.toMutableList()
                if (dragIndex in pts.indices) {
                    pts[dragIndex] = snapVertex(dragIndex, toWorld(pos))
                    if (!overlapsOthers(pts)) {
                        room = room.copy(points = pts)
                    }
                }
            }

            Drag.CUT_MOVE -> {
                val cs = room.cutouts.toMutableList()
                if (dragIndex in cs.indices) {
                    val w = toWorld(pos)
                    val c = cs[dragIndex]
                    val nx2 = round2(w.x - grabDx)
                    val ny2 = round2(w.y - grabDy)
                    fun tryPut(px: Double, py: Double): Boolean {
                        cs[dragIndex] = c.copy(x = px, y = py)
                        if (cutsOverlap(cs, dragIndex)) return false
                        // центр выреза не должен выходить за комнату — иначе он «улетает» наружу
                        val cc = Pt(px + c.w / 2, py + c.h / 2)
                        return pointInPolygon(cc, room.points)
                    }
                    if (!tryPut(nx2, ny2) && !tryPut(nx2, c.y) && !tryPut(c.x, ny2)) {
                        cs[dragIndex] = c
                    }
                    room = room.copy(cutouts = cs)
                }
            }

            Drag.CUT_RESIZE -> {
                val cs = room.cutouts.toMutableList()
                if (dragIndex in cs.indices) {
                    val w = toWorld(pos)
                    val c = cs[dragIndex]
                    val nw = max(0.1, round2(w.x - c.x))
                    val nh = max(0.1, round2(w.y - c.y))
                    fun trySize(pw: Double, ph: Double): Boolean {
                        cs[dragIndex] = c.copy(w = pw, h = ph)
                        return !cutsOverlap(cs, dragIndex)
                    }
                    if (!trySize(nw, nh) && !trySize(nw, c.h) && !trySize(c.w, nh)) {
                        cs[dragIndex] = c
                    }
                    room = room.copy(cutouts = cs)
                }
            }

            Drag.ZONE_MOVE -> {
                val wpt = toWorld(pos)
                updateZone(dragIndex) {
                    it.copy(x = round2(wpt.x - grabDx), y = round2(wpt.y - grabDy))
                }
            }

            Drag.ZONE_RESIZE -> {
                val wpt = toWorld(pos)
                updateZone(dragIndex) {
                    it.copy(
                        w = max(0.2, round2(wpt.x - it.x)),
                        h = max(0.2, round2(wpt.y - it.y)),
                    )
                }
            }

            Drag.FORMAT -> {
                brushTouch(toWorld(pos))
            }

            Drag.PAINT -> {
                val wpt = toWorld(pos)
                val idx = layout.tiles.indexOfFirst { pointInPolygon(wpt, it.corners) }
                if (idx >= 0) {
                    val key = tileKey(layout.tiles[idx])
                    if (tileColors[key] != paintColor) {
                        val m = tileColors.toMutableMap()
                        m[key] = paintColor
                        tileColors = m
                    }
                }
            }

            Drag.PLAN_MOVE -> {
                val wpt = toWorld(pos)
                planOrigin = Pt(wpt.x - grabDx, wpt.y - grabDy)
            }

            Drag.ROOM_MOVE -> {
                val wpt = toWorld(pos)
                val dx = wpt.x - grabDx
                val dy = wpt.y - grabDy
                grabDx = wpt.x
                grabDy = wpt.y

                fun shift(ddx: Double, ddy: Double): Boolean {
                    if (ddx == 0.0 && ddy == 0.0) return false
                    val cand = room.points.map { Pt(it.x + ddx, it.y + ddy) }
                    if (overlapsOthers(cand)) return false
                    room = RoomSpec(
                        cand,
                        room.cutouts.map { it.copy(x = it.x + ddx, y = it.y + ddy) },
                    )
                    pattern = pattern.copy(
                        offsetX = pattern.offsetX + ddx,
                        offsetY = pattern.offsetY + ddy,
                    )
                    if (movedFurn.isNotEmpty()) {
                        val fs = furniture.toMutableList()
                        movedFurn.forEach { idx ->
                            if (idx in fs.indices) {
                                val f = fs[idx]
                                fs[idx] = f.copy(x = f.x + ddx, y = f.y + ddy)
                            }
                        }
                        furniture = fs
                    }
                    return true
                }

                // упор в соседнюю комнату со скольжением вдоль её стены
                if (!shift(dx, dy)) {
                    shift(dx, 0.0)
                    shift(0.0, dy)
                }
                // магнит: подвели ближе 12 см к чужой стене — встаём вплотную, без щели
                val snap = snapOffset()
                if (snap != null) shift(snap.x, snap.y)
            }

            Drag.FURN_MOVE -> {
                val fs = furniture.toMutableList()
                if (dragIndex in fs.indices) {
                    val w = toWorld(pos)
                    val f = fs[dragIndex]
                    fs[dragIndex] = f.copy(x = round2(w.x - grabDx), y = round2(w.y - grabDy))
                    furniture = fs
                }
            }

            Drag.FURN_RESIZE -> {
                val fs = furniture.toMutableList()
                if (dragIndex in fs.indices) {
                    val w = toWorld(pos)
                    val f = fs[dragIndex]
                    fs[dragIndex] = f.copy(
                        w = max(0.2, round2(w.x - f.x)),
                        h = max(0.2, round2(w.y - f.y)),
                    )
                    furniture = fs
                }
            }

            Drag.NONE -> Unit
        }
    }

    fun gestureEnd() {
        if (drag == Drag.FORMAT) brushFinish()
        if (drag == Drag.PATTERN && !patternMoved) {
            selection = if (tappedTile >= 0) {
                if ((selection as? Selection.Tile)?.i == tappedTile) null else Selection.Tile(tappedTile)
            } else {
                null
            }
        }
        tappedTile = -1
        if (drag == Drag.PAN && !panMoved && pendingSwitch >= 0) {
            switchRoom(pendingSwitch)
        }
        pendingSwitch = -1
        if (drag == Drag.ROOM_MOVE) {
            // финальная привязка к сантиметрам, чтобы размеры оставались круглыми
            room = RoomSpec(
                room.points.map { Pt(round2(it.x), round2(it.y)) },
                room.cutouts.map { it.copy(x = round2(it.x), y = round2(it.y)) },
            )
            pattern = pattern.copy(
                offsetX = round2(pattern.offsetX),
                offsetY = round2(pattern.offsetY),
            )
        }
        gestureSnapped = false
        drag = Drag.NONE
        dragIndex = -1
    }

    /** Прервать текущий жест (например, при переходе к двупальцевому зуму). */
    fun cancelGesture() {
        gestureSnapped = false
        drag = Drag.NONE
        dragIndex = -1
    }

    /** Зум двумя пальцами: мировая точка под mid0 остаётся под mid. */
    fun pinch(base: ViewTransform, d0: Float, mid0: Offset, d: Float, mid: Offset) {
        if (d0 <= 0f) return
        val s = (base.scale * (d / d0)).coerceIn(12f, 2400f)
        val wx = (mid0.x - base.offset.x) / base.scale
        val wy = (mid0.y - base.offset.y) / base.scale
        view = ViewTransform(s, Offset(mid.x - wx * s, mid.y - wy * s))
    }

    private fun round2(v: Double) = Math.round(v * 100.0) / 100.0

    /** Округление до сантиметра + прилипание к координатам соседних вершин. */
    private fun snapVertex(i: Int, w: Pt): Pt {
        val pts = room.points
        var x = round2(w.x)
        var y = round2(w.y)
        val tol = 10.0 / view.scale
        val neighbours = listOf(pts[(i - 1 + pts.size) % pts.size], pts[(i + 1) % pts.size])
        for (n in neighbours) {
            if (abs(x - n.x) < tol) x = n.x
            if (abs(y - n.y) < tol) y = n.y
        }
        return Pt(x, y)
    }

    // ---------- плитка и узор ----------

    fun setTileWidth(mm: Double) {
        if (activeZone in zones.indices) {
            updateZone(activeZone) { it.copy(tile = it.tile.copy(widthMm = mm)) }
        } else {
            tile = tile.copy(widthMm = mm)
            reanchor()
        }
    }

    fun setTileHeight(mm: Double) {
        if (activeZone in zones.indices) {
            updateZone(activeZone) { it.copy(tile = it.tile.copy(heightMm = mm)) }
        } else {
            tile = tile.copy(heightMm = mm)
            reanchor()
        }
    }

    fun setGrout(mm: Double) {
        if (activeZone in zones.indices) {
            updateZone(activeZone) { it.copy(tile = it.tile.copy(groutMm = mm)) }
        } else {
            tile = tile.copy(groutMm = mm)
            reanchor()
        }
    }

    fun setPatternType(t: PatternType) {
        pushUndo()
        if (activeZone in zones.indices) {
            updateZone(activeZone) { it.copy(pattern = it.pattern.copy(type = t)) }
            return
        }
        pattern = pattern.copy(type = t)
        suggestions = null
        reanchor()
    }

    fun setRotation(deg: Double) { pattern = pattern.copy(rotationDeg = deg); reanchor() }

    // ---------- декор и точка отсчёта ----------

    /** Пересчитать смещение узора под выбранную точку отсчёта. */
    fun reanchor() {
        if (anchor != AnchorMode.FREE) {
            pattern = Aligner.applyAnchor(pattern, room.points, tile, anchor, decor.art)
        }
    }

    fun switchAnchor(a: AnchorMode) { anchor = a; reanchor() }

    fun setDecorMode(m: DecorMode) {
        pushUndo()
        decor = decor.copy(mode = m)
        if (m != DecorMode.NONE && anchor == AnchorMode.FREE) anchor = AnchorMode.ART_CENTER
        reanchor()
    }

    fun setArt(a: ArtRect) {
        decor = decor.copy(
            art = ArtRect(
                a.x.coerceIn(0.0, 0.9),
                a.y.coerceIn(0.0, 0.9),
                a.w.coerceIn(0.1, 1.0 - a.x.coerceIn(0.0, 0.9)),
                a.h.coerceIn(0.1, 1.0 - a.y.coerceIn(0.0, 0.9)),
            )
        )
        reanchor()
    }

    fun setPanel(cols: Int, rows: Int) { decor = decor.copy(panelCols = cols, panelRows = rows) }

    fun setEveryN(n: Int) { decor = decor.copy(everyN = n.coerceIn(2, 9)) }

    fun loadDecorImage(context: Context, uri: Uri) {
        viewModelScope.launch {
            val bmp = withContext(Dispatchers.IO) { decodeBitmap(context, uri) }
            if (bmp != null) {
                decorImage = bmp
                // старая рамка не должна применяться к новой картинке
                decor = decor.copy(art = ArtRect.FULL)
            }
        }
    }

    fun clearDecorImage() {
        decorImage = null
        decor = decor.copy(art = ArtRect.FULL)
    }

    fun resetShift() { pattern = pattern.copy(offsetX = 0.0, offsetY = 0.0) }

    fun setColor(c: Color) { tileColor = c; tileImage = null }

    fun toggleVariation() { variation = !variation }

    fun clearImage() { tileImage = null }

    private fun decodeBitmap(context: Context, uri: Uri): ImageBitmap? = runCatching {
        if (Build.VERSION.SDK_INT >= 28) {
            ImageDecoder.decodeBitmap(
                ImageDecoder.createSource(context.contentResolver, uri)
            ) { decoder, _, _ -> decoder.isMutableRequired = false }
        } else {
            @Suppress("DEPRECATION")
            MediaStore.Images.Media.getBitmap(context.contentResolver, uri)
        }
    }.getOrNull()?.asImageBitmap()

    fun loadTileImage(context: Context, uri: Uri) {
        viewModelScope.launch {
            val bmp = withContext(Dispatchers.IO) { decodeBitmap(context, uri) }
            if (bmp != null) tileImage = bmp
        }
    }

    // ---------- комната ----------

    fun applyRect(wM: Double, hM: Double) {
        pushUndo()
        room = RoomSpec(
            listOf(Pt(0.0, 0.0), Pt(wM, 0.0), Pt(wM, hM), Pt(0.0, hM)),
            room.cutouts.filter { it.x + it.w <= wM && it.y + it.h <= hM },
        )
        selection = null
        suggestions = null
        reanchor()
        fit()
    }

    fun applyLShape() {
        pushUndo()
        room = RoomSpec(
            listOf(
                Pt(0.0, 0.0), Pt(4.0, 0.0), Pt(4.0, 1.8),
                Pt(2.2, 1.8), Pt(2.2, 3.0), Pt(0.0, 3.0),
            ),
            emptyList(),
        )
        selection = null
        suggestions = null
        reanchor()
        fit()
    }

    /** Пересекается ли вырез idx с остальными (касание разрешено). */
    private fun cutsOverlap(cs: List<Cutout>, idx: Int): Boolean {
        val a = cs[idx]
        cs.forEachIndexed { j, b ->
            if (j != idx &&
                a.x < b.x + b.w - 0.001 && a.x + a.w > b.x + 0.001 &&
                a.y < b.y + b.h - 0.001 && a.y + a.h > b.y + 0.001
            ) {
                return true
            }
        }
        return false
    }

    fun addCutout() {
        pushUndo()
        val pts = room.points
        val cx = pts.sumOf { it.x } / pts.size
        val cy = pts.sumOf { it.y } / pts.size
        var nx3 = round2(cx - 0.4)
        val ny3 = round2(cy - 0.4)
        var tries = 0
        while (tries < 8) {
            val cand = room.cutouts + Cutout(nx3, ny3, 0.8, 0.8)
            if (!cutsOverlap(cand, cand.lastIndex)) break
            nx3 = round2(nx3 + 0.9)
            tries++
        }
        val cs = room.cutouts + Cutout(nx3, ny3, 0.8, 0.8)
        room = room.copy(cutouts = cs)
        roomMode = true
        selection = Selection.Cut(cs.lastIndex)
    }

    fun deleteSelectedVertex() {
        pushUndo()
        val sel = selection as? Selection.Vertex ?: return
        if (room.points.size <= 3) return
        val pts = room.points.toMutableList()
        if (sel.i !in pts.indices) return
        pts.removeAt(sel.i)
        room = room.copy(points = pts)
        selection = null
    }

    fun deleteSelectedCutout() {
        pushUndo()
        val sel = selection as? Selection.Cut ?: return
        val cs = room.cutouts.toMutableList()
        if (sel.i !in cs.indices) return
        cs.removeAt(sel.i)
        room = room.copy(cutouts = cs)
        selection = null
    }

    fun setSelectedCutW(m: Double) = updateSelectedCut { it.copy(w = max(0.1, m)) }

    fun setSelectedCutH(m: Double) = updateSelectedCut { it.copy(h = max(0.1, m)) }

    private fun updateSelectedCut(f: (Cutout) -> Cutout) {
        val sel = selection as? Selection.Cut ?: return
        val cs = room.cutouts.toMutableList()
        if (sel.i !in cs.indices) return
        cs[sel.i] = f(cs[sel.i])
        room = room.copy(cutouts = cs)
    }

    // ---------- цены и логотип ----------

    fun updatePrices(transform: (Prices) -> Prices) { prices = transform(prices) }

    private val logoFile: File
        get() = File(getApplication<Application>().filesDir, "logo.png")

    private fun decodeLogoFile(): ImageBitmap? = runCatching {
        android.graphics.BitmapFactory.decodeFile(logoFile.absolutePath)?.asImageBitmap()
    }.getOrNull()

    fun loadMasterLogo(context: Context, uri: Uri) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                runCatching {
                    context.contentResolver.openInputStream(uri)?.use { input ->
                        logoFile.outputStream().use { out -> input.copyTo(out) }
                    }
                }
            }
            masterLogo = withContext(Dispatchers.IO) { decodeLogoFile() }
        }
    }

    fun loadFitPhoto(context: Context, uri: Uri) {
        viewModelScope.launch {
            val bmp = withContext(Dispatchers.IO) { decodeBitmap(context, uri) }
            if (bmp != null) fitPhoto = bmp
        }
    }

    fun clearFitPhoto() { fitPhoto = null }

    fun moveFitCorner(i: Int, pos: Offset) {
        if (i !in 0..3) return
        val q = fitQuad.toMutableList()
        q[i] = Offset(pos.x.coerceIn(0f, 1f), pos.y.coerceIn(0f, 1f))
        fitQuad = q
    }

    fun resetFitQuad() {
        fitQuad = listOf(Offset(0.16f, 0.34f), Offset(0.84f, 0.34f), Offset(0.97f, 0.93f), Offset(0.03f, 0.93f))
    }

    fun updateFitAlpha(a: Float) { fitAlpha = a.coerceIn(0.3f, 1f) }

    /** Живой AR: раскладка рисуется в картинку и передаётся ARCore-экрану. */
    fun openAr(context: Context) {
        viewModelScope.launch {
            val result = withContext(Dispatchers.Default) {
                renderFloorBitmap(
                    points = room.points,
                    tiles = layout.tiles,
                    decorIdx = decorIdx,
                    tileBmp = tileImage?.asAndroidBitmap(),
                    decorBmp = (decorImage ?: tileImage)?.asAndroidBitmap(),
                    colorArgb = tileColor.toArgb(),
                    variation = variation,
                    panel = panelInfo(),
                    extra = zoneLayers(),
                    colorOf = { t -> colorOfTile(t) },
                    cutNumbers = showCuts,
                )
            }
            ArBridge.floorBitmap = result.first
            ArBridge.widthM = result.second
            ArBridge.heightM = result.third
            // варианты для показа клиенту: текущий + избранные форматы
            val label = tile.widthMm.toInt().toString() + "×" + tile.heightMm.toInt()
            val list = mutableListOf(label to result.first)
            withContext(Dispatchers.Default) {
                favTiles.filter { it.first != tile.widthMm || it.second != tile.heightMm }
                    .take(3)
                    .forEach { fav ->
                        val t2 = TileSpec(fav.first, fav.second, fav.third)
                        val lay = TilingEngine.build(room, t2, pattern)
                        val r2 = renderFloorBitmap(
                            points = room.points,
                            tiles = lay.tiles,
                            decorIdx = emptySet(),
                            tileBmp = tileImage?.asAndroidBitmap(),
                            decorBmp = null,
                            colorArgb = tileColor.toArgb(),
                            variation = variation,
                        )
                        list.add(
                            (fav.first.toInt().toString() + "×" + fav.second.toInt()) to r2.first,
                        )
                    }
            }
            ArBridge.variants = list
            val app2 = getApplication<Application>()
            ArBridge.info = String.format(Locale.getDefault(), "%.2f", layout.areaM2) + " " +
                app2.getString(R.string.unit_m2) + "  ·  " +
                app2.getString(R.string.buy) + " " + buyCount + " " + app2.getString(R.string.pcs) +
                "  ·  " + app2.getString(R.string.cut_tiles) + " " + layout.cutCount
            context.startActivity(Intent(context, ArActivity::class.java))
        }
    }

    fun clearMasterLogo() {
        masterLogo = null
        viewModelScope.launch(Dispatchers.IO) { runCatching { logoFile.delete() } }
    }

    /** Стоимость каждой отделанной поверхности: материалы и работа по текущим ценам. */
    fun surfaceCosts(): List<SurfaceCost> {
        val p = prices
        val tileAreaM2 = tile.widthMm * tile.heightMm / 1_000_000.0
        return model.surfaces.mapNotNull { su ->
            val fin = finishOf(su.id)
            if (fin == Finish.NONE) return@mapNotNull null
            val area = surfaceAreaM2(su.id)
            if (area <= 0.0) return@mapNotNull null
            var mat = 0.0
            var work = 0.0
            when (fin) {
                Finish.TILE -> {
                    val lay = surfaceLayout(su.id)
                    val pieces = ceil(lay.totalCount * (1 + reservePct / 100.0)).toInt()
                    val tileCost = if (p.tilePc > 0) pieces * p.tilePc else pieces * tileAreaM2 * p.tileM2
                    mat = tileCost + MaterialCalc.tileAdhesiveKg(area, tile) * p.adhesiveKg
                    work = area * p.workTileM2
                }

                Finish.WALLPAPER -> {
                    val wall = model.walls.firstOrNull { it.id == su.id }
                    val w = wall?.lengthM ?: sqrt(area)
                    val h = if (wall != null) wallHeightM else sqrt(area)
                    mat = MaterialCalc.wallpaper(w, h).rolls * p.roll
                    work = area * p.workWallM2
                }

                Finish.PAINT -> {
                    mat = MaterialCalc.paintLiters(area, 2) * p.paintL
                    work = area * p.workPaintM2
                }

                else -> Unit
            }
            SurfaceCost(su.id, fin, area, mat, work)
        }
    }

    // ---------- мебель ----------

    fun addFurniture(name: String, wM: Double, hM: Double, heightM: Double = 0.85, kind: String = "box") {
        pushUndo()
        val c = roomCenter()
        val f = Furniture(
            id = "f" + System.currentTimeMillis(),
            name = name,
            heightM = heightM,
            kind = kind,
            x = round2(c.x - wM / 2),
            y = round2(c.y - hM / 2),
            w = wM,
            h = hM,
        )
        furniture = furniture + f
        roomMode = true
        selection = Selection.Furn(furniture.lastIndex)
    }

    fun deleteSelectedFurniture() {
        pushUndo()
        val sel = selection as? Selection.Furn ?: return
        val fs = furniture.toMutableList()
        if (sel.i !in fs.indices) return
        fs.removeAt(sel.i)
        furniture = fs
        selection = null
    }

    fun setSelectedFurnW(m: Double) = updateSelectedFurn { it.copy(w = max(0.2, m)) }

    fun setSelectedFurnH(m: Double) = updateSelectedFurn { it.copy(h = max(0.2, m)) }

    fun toggleSelectedFurnCover() = updateSelectedFurn { it.copy(coversFinish = !it.coversFinish) }

    /** Повернуть объект на 90°: меняем ширину и глубину местами. */
    fun rotateSelectedFurn() = updateSelectedFurn { it.copy(w = it.h, h = it.w) }

    private fun updateSelectedFurn(f: (Furniture) -> Furniture) {
        val sel = selection as? Selection.Furn ?: return
        val fs = furniture.toMutableList()
        if (sel.i !in fs.indices) return
        fs[sel.i] = f(fs[sel.i])
        furniture = fs
    }

    /** Повернуть плитку на 90°: меняем ширину и длину местами. */
    fun rotateTile() {
        pushUndo()
        tile = tile.copy(widthMm = tile.heightMm, heightMm = tile.widthMm)
        reanchor()
    }

    // ---------- режимы и слои ----------

    fun setReserve(p: Int) { reservePct = p }

    fun switchRoomMode(b: Boolean) { roomMode = b; if (!b) selection = null }

    fun toggleDims() { showDims = !showDims }

    fun toggleCuts() { showCuts = !showCuts }

    fun toggleFurniture() { showFurniture = !showFurniture }

    fun toggleArt() { showArt = !showArt }

    fun setWallHeight(m: Double) { wallHeightM = m.coerceIn(1.8, 4.0) }

    // ---------- поверхности ----------

    /** Модель комнаты: пол, стены по контуру, потолок. */
    val model: RoomModel by derivedStateOf {
        RoomModel.fromFloor(room.points, wallHeightM, room.cutouts)
    }

    fun finishOf(id: String): Finish = finishes[id]
        ?: if (id == "floor") Finish.TILE else Finish.PAINT

    fun setFinish(id: String, f: Finish) {
        pushUndo()
        finishes = finishes + (id to f)
    }

    fun selectSurface(id: String) { activeSurface = id }

    fun openingsOf(id: String): List<Cutout> = openings[id] ?: emptyList()

    /** Добавить проём по центру стены: окно поднято над полом, дверь стоит на полу. */
    fun addOpening(id: String, wM: Double, hM: Double, fromFloorM: Double) {
        pushUndo()
        val wall = model.walls.firstOrNull { it.id == id } ?: return
        val x = ((wall.lengthM - wM) / 2).coerceAtLeast(0.0)
        val y = fromFloorM.coerceIn(0.0, (wallHeightM - hM).coerceAtLeast(0.0))
        openings = openings + (id to (openingsOf(id) + Cutout(round2(x), round2(y), wM, hM)))
    }

    fun deleteOpening(id: String, index: Int) {
        pushUndo()
        val list = openingsOf(id).toMutableList()
        if (index !in list.indices) return
        list.removeAt(index)
        openings = openings + (id to list)
    }

    /** Площадь поверхности за вычетом проёмов. */
    fun surfaceAreaM2(id: String): Double {
        val s = model.surfaces.firstOrNull { it.id == id } ?: return 0.0
        val holes = if (s.kind == SurfaceKind.WALL) openingsOf(id).sumOf { it.w * it.h } else 0.0
        return (s.areaM2() - holes).coerceAtLeast(0.0)
    }

    /** Раскладка плитки для стены или потолка (с учётом проёмов). */
    fun surfaceLayout(id: String): LayoutResult {
        val s = model.surfaces.firstOrNull { it.id == id } ?: return TilingEngine.build(room, tile, pattern)
        val spec = RoomSpec(s.outline, if (s.kind == SurfaceKind.WALL) openingsOf(id) else s.holes)
        return TilingEngine.build(spec, tile, pattern)
    }

    // ---------- советы ----------

    fun runSuggest() {
        viewModelScope.launch {
            val s = withContext(Dispatchers.Default) {
                LayoutSuggester.suggest(room, tile, pattern)
            }
            suggestions = s
        }
    }

    fun applySuggestion(s: LayoutSuggester.Suggestion) {
        pattern = pattern.copy(type = s.type, rotationDeg = s.rotationDeg)
        suggestions = null
    }

    // ---------- проекты ----------

    private fun toast(resId: Int) {
        Toast.makeText(getApplication(), getApplication<Application>().getString(resId), Toast.LENGTH_SHORT).show()
    }

    fun refreshProjects() {
        viewModelScope.launch {
            projects = withContext(Dispatchers.IO) { repo.list() }
        }
    }

    private fun currentDto(): ProjectDto {
        syncActiveRoom()
        val n = projectName.ifBlank { getApplication<Application>().getString(R.string.default_name) }
        return ProjectDto(
            name = n,
            room = room,
            tile = tile,
            pattern = pattern,
            colorArgb = tileColor.toArgb(),
            variation = variation,
            reservePct = reservePct,
            decor = decor,
            anchor = anchor,
            furniture = furniture,
            finishes = finishes,
            openings = openings,
            wallHeightM = wallHeightM,
            wallThicknessM = wallThicknessM,
            prices = prices,
            rooms = rooms,
            activeRoom = activeRoom,
            savedAt = System.currentTimeMillis(),
        )
    }

    fun saveProject() {
        val dto = currentDto()
        viewModelScope.launch {
            withContext(Dispatchers.IO) { repo.save(dto) }
            projectName = dto.name
            refreshProjects()
            toast(R.string.saved)
        }
    }

    private fun applyDto(dto: ProjectDto) {
        room = dto.room
        tile = dto.tile
        pattern = dto.pattern
        tileColor = Color(dto.colorArgb)
        tileImage = null
        variation = dto.variation
        reservePct = dto.reservePct
        decor = dto.decor
        anchor = dto.anchor
        furniture = dto.furniture
        finishes = dto.finishes
        openings = dto.openings
        wallHeightM = dto.wallHeightM
        wallThicknessM = dto.wallThicknessM
        prices = dto.prices
        if (dto.rooms.isNotEmpty()) {
            rooms = dto.rooms
            activeRoom = dto.activeRoom.coerceIn(0, dto.rooms.lastIndex)
            applyRoom(rooms[activeRoom])
        } else {
            rooms = listOf(snapshotRoom(""))
            activeRoom = 0
        }
        projectName = dto.name
        selection = null
        suggestions = null
        fit()
    }

    /**
     * Упрощение контура: сливает точки ближе 4 см и убирает те, что лежат
     * почти на прямой (отклонение меньше 2 см). Форма остаётся, каша уходит.
     */
    fun simplifyRoom() {
        val pts = room.points
        if (pts.size < 4) return
        val merged = ArrayList<Pt>(pts.size)
        for (p in pts) {
            val last = merged.lastOrNull()
            if (last == null || sqrt((p.x - last.x) * (p.x - last.x) + (p.y - last.y) * (p.y - last.y)) > 0.04) {
                merged.add(p)
            }
        }
        while (merged.size > 3) {
            val a = merged.first()
            val b = merged.last()
            if (sqrt((a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y)) < 0.04) {
                merged.removeAt(merged.size - 1)
            } else {
                break
            }
        }
        val out = ArrayList<Pt>(merged.size)
        for (i in merged.indices) {
            val prev = merged[(i - 1 + merged.size) % merged.size]
            val cur = merged[i]
            val next = merged[(i + 1) % merged.size]
            val vx = next.x - prev.x
            val vy = next.y - prev.y
            val len = sqrt(vx * vx + vy * vy)
            val dist = if (len < 1e-9) {
                0.0
            } else {
                abs((cur.x - prev.x) * vy - (cur.y - prev.y) * vx) / len
            }
            if (dist > 0.02) out.add(cur)
        }
        if (out.size < 3) return
        pushUndo()
        room = room.copy(points = out.map { Pt(round2(it.x), round2(it.y)) })
        selection = null
        reanchor()
    }

    /** Общий сброс оформления: убирает всё «наставленное», геометрию не трогает. */
    fun resetPlacements() {
        pushUndo()
        tileColors = emptyMap()
        decorOverrides = emptyMap()
        panelOn = false
        zones = emptyList()
        activeZone = -1
        furniture = emptyList()
        decor = DecorSpec()
        paintMode = false
        highlightCut = null
        selection = null
    }

    /** Чистый лист для нового объекта; расценки и логотип мастера остаются. */
    fun newProject() {
        pushUndo()
        projectName = ""
        room = RoomSpec(listOf(Pt(0.0, 0.0), Pt(4.0, 0.0), Pt(4.0, 3.0), Pt(0.0, 3.0)))
        tile = TileSpec(600.0, 600.0, 3.0)
        pattern = PatternSpec()
        tileColor = Color(0xFFC7CCD6)
        tileImage = null
        decorImage = null
        variation = true
        reservePct = 10
        decor = DecorSpec()
        anchor = AnchorMode.FREE
        furniture = emptyList()
        finishes = mapOf("floor" to Finish.TILE, "ceiling" to Finish.PAINT)
        openings = emptyMap()
        decorOverrides = emptyMap()
        panelOn = false
        zones = emptyList()
        tileColors = emptyMap()
        activeZone = -1
        wallHeightM = 2.7
        wallThicknessM = 0.10
        rooms = emptyList()
        activeRoom = 0
        rooms = listOf(snapshotRoom(""))
        selection = null
        suggestions = null
        reanchor()
        fit()
    }

    fun loadProject(name: String) {
        viewModelScope.launch {
            val dto = withContext(Dispatchers.IO) { repo.load(name) } ?: return@launch
            applyDto(dto)
            toast(R.string.loaded)
        }
    }

    fun deleteProject(name: String) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { repo.delete(name) }
            if (projectName == name) projectName = ""
            refreshProjects()
            toast(R.string.deleted)
        }
    }

    init {
        favTiles = (favPrefs().getString("tiles", "") ?: "")
            .split(";")
            .mapNotNull { part ->
                val p3 = part.split(":")
                if (p3.size == 3) {
                    val a = p3[0].toDoubleOrNull()
                    val b = p3[1].toDoubleOrNull()
                    val c = p3[2].toDoubleOrNull()
                    if (a != null && b != null && c != null) Triple(a, b, c) else null
                } else null
            }
        // Все init-блоки живут в самом конце класса: Kotlin выполняет инициализацию
        // строго сверху вниз, поэтому отсюда все свойства выше гарантированно созданы.
        repo.loadAutosave()?.let { applyDto(it) }
        if (rooms.isEmpty()) rooms = listOf(snapshotRoom(""))
        viewModelScope.launch {
            masterLogo = withContext(Dispatchers.IO) { decodeLogoFile() }
        }
        // автосохранение: через 1.3 с после любого изменения пишем черновик
        viewModelScope.launch {
            snapshotFlow {
                listOf(
                    rooms, activeRoom, room, tile, pattern, tileColor, variation, reservePct,
                    decor, anchor, furniture, finishes, openings, wallHeightM, prices, projectName,
                )
            }.collectLatest {
                delay(1300)
                val dto = currentDto()
                withContext(Dispatchers.IO) { repo.saveAutosave(dto) }
            }
        }
    }
}
